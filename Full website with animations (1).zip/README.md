
  # Full website with animations

  This is a code bundle for Full website with animations. The original project is available at https://www.figma.com/design/czvRf9iqiHYx2ccKZbHf6h/Full-website-with-animations.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  