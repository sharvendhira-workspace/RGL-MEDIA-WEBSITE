import { motion } from "motion/react";
import { useState } from "react";
import { toast } from "sonner";

export default function Contact() {
  return (
    <div className="pt-[80px]">
      <HeroSection />
      <ContactFormSection />
      <ContactInfoSection />
      <MapSection />
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative bg-[#0b1f17] h-[500px] overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(180deg, rgb(11, 31, 23) 0%, rgb(19, 42, 33) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute bg-[rgba(200,169,91,0.08)] blur-[80px] left-1/2 -translate-x-1/2 rounded-full w-[600px] h-[600px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 h-full flex items-center justify-center text-center">
        <div className="max-w-[900px]">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] tracking-[1.32px] mb-6"
          >
            ✦ GET IN TOUCH ✦
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[36px] md:text-[56px] lg:text-[72px] leading-[1.15] text-[#f5f5f5] mb-6"
          >
            Let's Talk About Your Vision
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[20px] leading-[32px]"
          >
            Whether it's a wedding film or commercial project, we're here to bring your story to
            life.
          </motion.p>
        </div>
      </div>
    </section>
  );
}

function ContactFormSection() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    service: "wedding",
    date: "",
    message: "",
  });

  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);

    await new Promise((resolve) => setTimeout(resolve, 1500));

    toast.success("Message sent! We'll get back to you within 24 hours.", {
      duration: 4000,
    });

    setFormData({
      name: "",
      email: "",
      phone: "",
      service: "wedding",
      date: "",
      message: "",
    });

    setIsSubmitting(false);
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section className="relative bg-[#132a21] py-24">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.05)] blur-[60px] left-1/2 -translate-x-1/2 rounded-full w-[500px] h-[500px] top-[100px]"
      />

      <div className="relative max-w-[1200px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ SEND US A MESSAGE ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Book a Consultation
        </motion.p>

        <motion.form
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          onSubmit={handleSubmit}
          className="backdrop-blur-[6px] bg-[rgba(14,36,27,0.6)] border border-[rgba(200,169,91,0.5)] overflow-hidden rounded-[20px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.3)] p-10"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            <div>
              <label className="block font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[13px] tracking-[0.39px] mb-2">
                Your Name *
              </label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                required
                className="w-full bg-[rgba(11,31,23,0.8)] border border-[rgba(200,169,91,0.3)] rounded-[12px] px-4 py-3 font-['Inter:Regular',sans-serif] text-[#f5f5f5] text-[15px] focus:border-[#c8a95b] focus:outline-none transition-colors"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[13px] tracking-[0.39px] mb-2">
                Email Address *
              </label>
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleChange}
                required
                className="w-full bg-[rgba(11,31,23,0.8)] border border-[rgba(200,169,91,0.3)] rounded-[12px] px-4 py-3 font-['Inter:Regular',sans-serif] text-[#f5f5f5] text-[15px] focus:border-[#c8a95b] focus:outline-none transition-colors"
                placeholder="john@example.com"
              />
            </div>

            <div>
              <label className="block font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[13px] tracking-[0.39px] mb-2">
                Phone Number *
              </label>
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleChange}
                required
                className="w-full bg-[rgba(11,31,23,0.8)] border border-[rgba(200,169,91,0.3)] rounded-[12px] px-4 py-3 font-['Inter:Regular',sans-serif] text-[#f5f5f5] text-[15px] focus:border-[#c8a95b] focus:outline-none transition-colors"
                placeholder="+91 98426 12090"
              />
            </div>

            <div>
              <label className="block font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[13px] tracking-[0.39px] mb-2">
                Service Interested In *
              </label>
              <select
                name="service"
                value={formData.service}
                onChange={handleChange}
                required
                className="w-full bg-[rgba(11,31,23,0.8)] border border-[rgba(200,169,91,0.3)] rounded-[12px] px-4 py-3 font-['Inter:Regular',sans-serif] text-[#f5f5f5] text-[15px] focus:border-[#c8a95b] focus:outline-none transition-colors"
              >
                <option value="wedding">Wedding Film</option>
                <option value="commercial">Commercial Ad</option>
                <option value="product">Product Film</option>
                <option value="social">Social Media Content</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="md:col-span-2">
              <label className="block font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[13px] tracking-[0.39px] mb-2">
                Event / Project Date
              </label>
              <input
                type="date"
                name="date"
                value={formData.date}
                onChange={handleChange}
                className="w-full bg-[rgba(11,31,23,0.8)] border border-[rgba(200,169,91,0.3)] rounded-[12px] px-4 py-3 font-['Inter:Regular',sans-serif] text-[#f5f5f5] text-[15px] focus:border-[#c8a95b] focus:outline-none transition-colors"
              />
            </div>

            <div className="md:col-span-2">
              <label className="block font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[13px] tracking-[0.39px] mb-2">
                Tell Us About Your Project *
              </label>
              <textarea
                name="message"
                value={formData.message}
                onChange={handleChange}
                required
                rows={6}
                className="w-full bg-[rgba(11,31,23,0.8)] border border-[rgba(200,169,91,0.3)] rounded-[12px] px-4 py-3 font-['Inter:Regular',sans-serif] text-[#f5f5f5] text-[15px] focus:border-[#c8a95b] focus:outline-none transition-colors resize-none"
                placeholder="Share your vision, ideas, or any specific requirements..."
              />
            </div>
          </div>

          <motion.button
            type="submit"
            disabled={isSubmitting}
            whileHover={{ scale: isSubmitting ? 1 : 1.02 }}
            whileTap={{ scale: isSubmitting ? 1 : 0.98 }}
            className={`w-full h-[56px] rounded-[28px] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[15px] tracking-[0.45px] transition-all ${
              isSubmitting
                ? "bg-[rgba(200,169,91,0.5)] text-[#0b1f17] cursor-not-allowed"
                : "bg-[#c8a95b] text-[#0b1f17] shadow-[0px_8px_32px_0px_rgba(200,169,91,0.5)]"
            }`}
          >
            {isSubmitting ? "Sending..." : "Send Message"}
          </motion.button>
        </motion.form>
      </div>
    </section>
  );
}

function ContactInfoSection() {
  const contactMethods = [
    {
      icon: "📧",
      title: "Email",
      value: "rglmediaa@gmail.com",
      link: "mailto:rglmediaa@gmail.com",
    },
    {
      icon: "📞",
      title: "Phone",
      value: "+91 98426 12090",
      link: "tel:+919842612090",
    },
    {
      icon: "💬",
      title: "WhatsApp",
      value: "Chat with us",
      link: "https://wa.me/919842612090",
    },
    {
      icon: "📸",
      title: "Instagram",
      value: "@rglmedia",
      link: "https://instagram.com/rglmedia",
    },
  ];

  return (
    <section className="relative bg-[#0b1f17] py-24">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(180deg, rgb(5, 15, 11) 0%, rgb(11, 31, 23) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ REACH US ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Other Ways to Connect
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {contactMethods.map((method, index) => (
            <motion.a
              key={method.title}
              href={method.link}
              target={method.link.startsWith("http") ? "_blank" : undefined}
              rel={method.link.startsWith("http") ? "noopener noreferrer" : undefined}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -10 }}
              className="backdrop-blur-[6px] bg-[rgba(14,36,27,0.6)] border border-[rgba(200,169,91,0.5)] overflow-hidden rounded-[16px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.3)] p-8 text-center cursor-pointer"
            >
              <p className="text-[48px] mb-4">{method.icon}</p>
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#c8a95b] text-[16px] mb-2">
                {method.title}
              </p>
              <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[14px]">
                {method.value}
              </p>
            </motion.a>
          ))}
        </div>
      </div>
    </section>
  );
}

function MapSection() {
  const locations = [
    { city: "Chennai", region: "Primary Studio" },
    { city: "Coimbatore", region: "Service Area" },
    { city: "Salem", region: "Service Area" },
  ];

  return (
    <section className="relative bg-[#132a21] py-24">
      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ WHERE WE WORK ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Our Locations
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {locations.map((location, index) => (
            <motion.div
              key={location.city}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05 }}
              className="backdrop-blur-[4px] bg-[rgba(14,36,27,0.5)] border border-[rgba(200,169,91,0.4)] rounded-[16px] p-8 text-center"
            >
              <p className="text-[48px] mb-3">📍</p>
              <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#c8a95b] text-[28px] mb-2">
                {location.city}
              </p>
              <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[14px]">
                {location.region}
              </p>
            </motion.div>
          ))}
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="bg-gradient-to-br from-[#0a1c14] to-[#030a07] border border-[rgba(200,169,91,0.5)] h-[400px] rounded-[20px] shadow-[0px_30px_60px_-10px_rgba(0,0,0,0.5)] flex items-center justify-center"
        >
          <div className="text-center">
            <p className="text-[64px] mb-4">🗺️</p>
            <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#f5f5f5] text-[24px] mb-2">
              Serving Tamil Nadu
            </p>
            <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[16px]">
              Chennai · Coimbatore · Salem
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
