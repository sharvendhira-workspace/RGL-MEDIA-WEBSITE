import { motion } from "motion/react";
import { Link } from "react-router";

export default function About() {
  return (
    <div className="pt-[80px]">
      <HeroSection />
      <StorySection />
      <TeamSection />
      <ValuesSection />
      <CTASection />
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative bg-[#0b1f17] h-[600px] overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(90deg, rgb(5, 15, 11) 0%, rgb(11, 31, 23) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute bg-[rgba(200,169,91,0.08)] blur-[80px] left-1/2 -translate-x-1/2 rounded-full w-[600px] h-[600px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 h-full flex items-center justify-center text-center">
        <div className="max-w-[900px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[36px] md:text-[56px] lg:text-[72px] leading-[1.15] text-[#f5f5f5] mb-6"
          >
            Where Stories Come Alive
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[20px] leading-[32px]"
          >
            We're a Chennai-based creative production studio specializing in cinematic storytelling
            through wedding films and commercial advertising.
          </motion.p>
        </div>
      </div>
    </section>
  );
}

function StorySection() {
  return (
    <section className="relative bg-[#132a21] py-24">
      <div className="relative max-w-[1200px] mx-auto px-4 sm:px-8 md:px-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <p className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] tracking-[1.32px] mb-4">
              ✦ OUR STORY ✦
            </p>

            <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[30px] md:text-[40px] lg:text-[48px] leading-[1.2] mb-6">
              Built on Passion for Visual Storytelling
            </p>

            <div className="bg-[#c8a95b] h-[2px] w-[50px] mb-6" />

            <div className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[16px] leading-[28px] space-y-4">
              <p>
                RGL Media was founded with a simple belief: every story deserves to be told with
                cinematic beauty and emotional depth.
              </p>
              <p>
                What started as a passion project has grown into a full-service production studio,
                serving clients across Chennai, Coimbatore, and Salem. We've filmed over 50
                weddings and produced countless commercial campaigns.
              </p>
              <p>
                Our approach combines technical excellence with artistic vision, ensuring every
                frame we capture tells a compelling story.
              </p>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative"
          >
            <div className="bg-gradient-to-br from-[#0a1c14] to-[#030a07] border border-[rgba(200,169,91,0.5)] h-[500px] rounded-[20px] shadow-[0px_30px_60px_-10px_rgba(0,0,0,0.5)] flex items-center justify-center">
              <div className="text-center">
                <p className="text-[80px] mb-4">🎥</p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px]">
                  Behind Every Frame
                </p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[rgba(200,169,91,0.8)] text-[14px] mt-2">
                  Chennai · India
                </p>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function TeamSection() {
  const team = [
    {
      name: "Rajesh Kumar",
      role: "Founder & Creative Director",
      emoji: "🎬",
    },
    {
      name: "Ganesh Babu",
      role: "Lead Cinematographer",
      emoji: "📹",
    },
    {
      name: "Lakshmi Priya",
      role: "Post-Production Head",
      emoji: "✂️",
    },
  ];

  return (
    <section className="relative bg-[#0b1f17] py-24">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(180deg, rgb(5, 15, 11) 0%, rgb(11, 31, 23) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ THE TEAM ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Meet The Creators
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {team.map((member, index) => (
            <motion.div
              key={member.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.05, y: -10 }}
              className="backdrop-blur-[6px] bg-[rgba(14,36,27,0.6)] border border-[rgba(200,169,91,0.5)] overflow-hidden rounded-[20px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.3)] p-8 text-center"
            >
              <motion.p
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.3 + index * 0.2 }}
                className="text-[64px] mb-4"
              >
                {member.emoji}
              </motion.p>

              <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[22px] mb-2">
                {member.name}
              </p>

              <p className="font-['Inter:Light',sans-serif] font-light text-[#c8a95b] text-[14px]">
                {member.role}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ValuesSection() {
  const values = [
    {
      icon: "🎯",
      title: "Intentional",
      description: "Every frame is crafted with purpose and precision",
    },
    {
      icon: "💫",
      title: "Authentic",
      description: "We capture genuine moments and real emotions",
    },
    {
      icon: "🎨",
      title: "Creative",
      description: "Pushing boundaries with innovative storytelling",
    },
    {
      icon: "⚡",
      title: "Professional",
      description: "Delivering excellence in every project",
    },
  ];

  return (
    <section className="relative bg-[#132a21] py-24">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.05)] blur-[60px] left-1/2 -translate-x-1/2 rounded-full w-[500px] h-[500px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ OUR VALUES ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          What Drives Us
        </motion.p>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
          {values.map((value, index) => (
            <motion.div
              key={value.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="backdrop-blur-[4px] bg-[rgba(14,36,27,0.4)] border border-[rgba(200,169,91,0.4)] rounded-[16px] p-6 text-center"
            >
              <p className="text-[48px] mb-3">{value.icon}</p>
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#c8a95b] text-[18px] mb-2">
                {value.title}
              </p>
              <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[13px] leading-[20px]">
                {value.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="relative bg-[#132a21] py-24">
      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-[800px] mx-auto"
        >
          <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] leading-[1.15] mb-6">
            Let's Create Together
          </p>

          <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px] mb-10">
            Ready to bring your vision to life? We'd love to hear about your project.
          </p>

          <Link to="/contact">
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: "0px 12px 40px 0px rgba(200,169,91,0.6)" }}
              whileTap={{ scale: 0.95 }}
              className="bg-[#c8a95b] h-[60px] px-12 rounded-[30px] shadow-[0px_8px_32px_0px_rgba(200,169,91,0.5)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[16px] tracking-[0.48px]"
            >
              Get in Touch
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
