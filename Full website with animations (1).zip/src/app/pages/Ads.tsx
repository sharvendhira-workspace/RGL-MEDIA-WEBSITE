import { motion } from "motion/react";
import { Link } from "react-router";
import { useState } from "react";
import VideoModal from "../components/VideoModal";

export default function Ads() {
  const [videoModal, setVideoModal] = useState<{
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string;
    videoType?: "youtube" | "vimeo" | "direct";
  }>({
    isOpen: false,
    title: "",
    category: "",
    videoUrl: "",
    videoType: "youtube",
  });

  return (
    <div className="pt-[80px]">
      <HeroSection />
      <ServicesSection />
      <PortfolioSection setVideoModal={setVideoModal} />
      <BrandSection />
      <CTASection />

      <VideoModal
        isOpen={videoModal.isOpen}
        onClose={() =>
          setVideoModal({
            isOpen: false,
            title: "",
            category: "",
            videoUrl: "",
            videoType: "youtube",
          })
        }
        videoTitle={videoModal.title}
        videoCategory={videoModal.category}
        videoUrl={videoModal.videoUrl}
        videoType={videoModal.videoType}
      />
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative bg-[#0b1f17] h-[600px] overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(225deg, rgb(11, 31, 23) 0%, rgb(19, 42, 33) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute bg-[rgba(200,169,91,0.08)] blur-[80px] right-[200px] rounded-full w-[600px] h-[600px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 h-full flex items-center">
        <div className="max-w-[800px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[36px] md:text-[56px] lg:text-[72px] leading-[1.15] mb-6"
          >
            <p className="mb-0">
              <span className="text-[#f5f5f5]">Elevate Your Brand</span>
            </p>
            <p>
              <span className="text-[#e5b94c]">With Cinematic Ads.</span>
            </p>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[20px] leading-[32px] mb-8"
          >
            We create powerful commercial content that captivates audiences and drives results.
            From brand campaigns to product launches, we tell your story with visual impact.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.1 }}
          >
            <Link to="/contact">
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0px 12px 32px 0px rgba(200,169,91,0.5)" }}
                whileTap={{ scale: 0.95 }}
                className="bg-[#c8a95b] h-[56px] px-10 rounded-[28px] shadow-[0px_8px_24px_0px_rgba(200,169,91,0.4)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[15px] tracking-[0.45px]"
              >
                Start Your Campaign
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function ServicesSection() {
  const services = [
    {
      icon: "🎥",
      title: "Brand Campaigns",
      description: "Full-scale brand storytelling that connects with your audience emotionally",
    },
    {
      icon: "📦",
      title: "Product Films",
      description: "Showcase your products with cinematic detail and creative direction",
    },
    {
      icon: "📱",
      title: "Social Media Content",
      description: "Short-form vertical videos optimized for Instagram, YouTube & TikTok",
    },
    {
      icon: "🎬",
      title: "Promotional Videos",
      description: "High-impact promotional content for launches, events, and announcements",
    },
    {
      icon: "🏢",
      title: "Corporate Videos",
      description: "Professional corporate films, testimonials, and company profiles",
    },
    {
      icon: "✨",
      title: "Visual Effects",
      description: "Advanced VFX and motion graphics to enhance your brand narrative",
    },
  ];

  return (
    <section className="relative bg-[#132a21] py-24 overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.05)] blur-[60px] left-1/2 -translate-x-1/2 rounded-full w-[500px] h-[500px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ WHAT WE OFFER ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Our Services
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -10 }}
              className="backdrop-blur-[6px] bg-[rgba(14,36,27,0.6)] border border-[rgba(200,169,91,0.5)] overflow-hidden rounded-[20px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.3)] p-8"
            >
              <motion.p
                initial={{ scale: 0 }}
                whileInView={{ scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.4, delay: 0.3 + index * 0.1 }}
                className="text-[48px] mb-4"
              >
                {service.icon}
              </motion.p>

              <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[24px] mb-3">
                {service.title}
              </p>

              <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[15px] leading-[24px]">
                {service.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

interface PortfolioSectionProps {
  setVideoModal: (modal: {
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string;
    videoType?: "youtube" | "vimeo" | "direct";
  }) => void;
}

function PortfolioSection({ setVideoModal }: PortfolioSectionProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  const portfolio = [
    {
      title: "SCOOPE ICE CREAM",
      brand: "RGL MEDIA",
      category: "Brand Campaign",
      videoUrl: "https://www.youtube.com/watch?v=h2Mz61r9fzA",
      videoType: "youtube" as const,
      thumbnail: "https://img.youtube.com/vi/h2Mz61r9fzA/hqdefault.jpg",
    },
    {
      title: "SELVA MALIGAI",
      brand: "RGL MEDIA",
      category: "Product Film",
      videoUrl: "https://www.youtube.com/watch?v=xlKTkBYz27A",
      videoType: "youtube" as const,
      thumbnail: "https://img.youtube.com/vi/xlKTkBYz27A/hqdefault.jpg",
    },
    {
      title: "VGM HOSPITAL",
      brand: "RGL MEDIA",
      category: "Promotional",
      videoUrl: "https://www.youtube.com/watch?v=kgU8qqdsLdc",
      videoType: "youtube" as const,
      thumbnail: "https://img.youtube.com/vi/kgU8qqdsLdc/hqdefault.jpg",
    },
  ];

  return (
    <section className="relative bg-[#0b1f17] py-24 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(180deg, rgb(5, 15, 11) 0%, rgb(11, 31, 23) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ RECENT WORK ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Featured Campaigns
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-[1200px] mx-auto">
          {portfolio.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -10 }}
              onHoverStart={() => setHoveredIndex(index)}
              onHoverEnd={() => setHoveredIndex(null)}
              onClick={() =>
                setVideoModal({
                  isOpen: true,
                  title: item.title,
                  category: item.category,
                  videoUrl: item.videoUrl,
                  videoType: item.videoType,
                })
              }
              className="bg-[#081711] border border-[rgba(200,169,91,0.5)] h-[520px] overflow-hidden rounded-[20px] shadow-[0px_20px_50px_-5px_rgba(0,0,0,0.6)] relative cursor-pointer"
            >
              {/* Thumbnail Background */}
              <div className="absolute inset-0 overflow-hidden bg-[#0a1c14]">
                <motion.img
                  initial={{ scale: 1 }}
                  animate={{ scale: hoveredIndex === index ? 1.05 : 1 }}
                  transition={{ duration: 0.4 }}
                  src={item.thumbnail}
                  alt={item.title}
                  className="w-full h-full object-cover"
                  loading="eager"
                  onError={(e) => {
                    // Fallback to default thumbnail if hqdefault fails
                    const target = e.currentTarget as HTMLImageElement;
                    if (!target.src.includes('default.jpg')) {
                      const videoId = item.thumbnail.split('/')[4].split('.')[0];
                      target.src = `https://img.youtube.com/vi/${videoId}/default.jpg`;
                    }
                  }}
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-b from-[rgba(10,28,20,0.5)] to-[rgba(3,10,7,0.85)]" />
              <div className="absolute left-0 right-0 bottom-0 h-[150px] bg-gradient-to-b from-transparent to-[rgba(3,9,6,0.95)]" />

              <div className="absolute top-4 left-4 bg-[rgba(11,31,23,0.9)] border border-[rgba(200,169,91,0.4)] h-[28px] px-3 rounded-[14px] flex items-center">
                <p className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[10px] tracking-[0.6px]">
                  {item.category}
                </p>
              </div>

              <motion.div
                animate={{
                  scale: hoveredIndex === index ? 1.2 : 1,
                  opacity: hoveredIndex === index ? 1 : 0.9,
                }}
                transition={{ duration: 0.3 }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[rgba(200,169,91,0.2)] border-2 border-[rgba(200,169,91,0.9)] rounded-full w-[72px] h-[72px] flex items-center justify-center backdrop-blur-sm shadow-[0px_8px_24px_0px_rgba(200,169,91,0.3)]"
              >
                <div className="w-0 h-0 border-t-[12px] border-t-transparent border-l-[20px] border-l-[#c8a95b] border-b-[12px] border-b-transparent ml-1" />
              </motion.div>

              <div className="absolute bottom-6 left-6 right-6">
                <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#f5f5f5] text-[18px] mb-1">
                  {item.title}
                </p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[13px]">
                  {item.brand}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function BrandSection() {
  const brands = [
    "TechCorp",
    "Elegance Fashion",
    "FitLife",
    "Urban Living",
    "Flavors Restaurant",
    "DriveX Auto",
    "EcoGreen",
    "PixelPerfect",
  ];

  return (
    <section className="relative bg-[#132a21] py-24">
      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ TRUSTED BY ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Brands We've Worked With
        </motion.p>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {brands.map((brand, index) => (
            <motion.div
              key={brand}
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.1 }}
              className="backdrop-blur-[4px] bg-[rgba(14,36,27,0.4)] border border-[rgba(200,169,91,0.3)] h-[120px] rounded-[12px] flex items-center justify-center"
            >
              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#c8a95b] text-[18px]">
                {brand}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="relative bg-[#0b1f17] py-24">
      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-[800px] mx-auto"
        >
          <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] leading-[1.15] mb-6">
            Let's Grow Your Brand
          </p>

          <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px] mb-10">
            Ready to create content that converts? Let's discuss your next campaign.
          </p>

          <Link to="/contact">
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: "0px 12px 40px 0px rgba(200,169,91,0.6)" }}
              whileTap={{ scale: 0.95 }}
              className="bg-[#c8a95b] h-[60px] px-12 rounded-[30px] shadow-[0px_8px_32px_0px_rgba(200,169,91,0.5)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[16px] tracking-[0.48px]"
            >
              Start Your Project
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
