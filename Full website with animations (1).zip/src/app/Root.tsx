import { Outlet, useLocation } from "react-router";
import { useEffect } from "react";
import { Toaster } from "sonner";
import Navbar from "./components/Navbar";
import Footer from "./components/Footer";

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [pathname]);
  return null;
}

export default function Root() {
  return (
    <div className="min-h-screen bg-[#0b1f17]">
      <ScrollToTop />
      <Navbar />
      <Outlet />
      <Footer />
      <Toaster
        position="top-right"
        toastOptions={{
          style: {
            background: "rgba(14, 36, 27, 0.95)",
            border: "1px solid rgba(200, 169, 91, 0.5)",
            color: "#f5f5f5",
          },
        }}
      />
    </div>
  );
}
