import { motion } from "motion/react";
import { useState } from "react";

interface VideoPlayerProps {
  videoUrl: string;
  type?: "youtube" | "vimeo" | "direct";
  poster?: string;
  autoplay?: boolean;
  loop?: boolean;
  muted?: boolean;
  controls?: boolean;
  className?: string;
}

export default function VideoPlayer({
  videoUrl,
  type = "youtube",
  poster,
  autoplay = false,
  loop = false,
  muted = false,
  controls = true,
  className = "",
}: VideoPlayerProps) {
  const [isLoaded, setIsLoaded] = useState(false);

  // Extract video ID from YouTube URL
  const getYouTubeId = (url: string) => {
    const match = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
    return match ? match[1] : url;
  };

  // Extract video ID from Vimeo URL
  const getVimeoId = (url: string) => {
    const match = url.match(/(?:vimeo\.com\/)(\d+)/);
    return match ? match[1] : url;
  };

  if (type === "youtube") {
    const videoId = getYouTubeId(videoUrl);
    const embedUrl = `https://www.youtube.com/embed/${videoId}?autoplay=${autoplay ? 1 : 0}&loop=${loop ? 1 : 0}&mute=${muted ? 1 : 0}&controls=${controls ? 1 : 0}${loop ? `&playlist=${videoId}` : ""}`;

    return (
      <div className={`relative w-full aspect-video bg-[#0a1c14] rounded-[16px] overflow-hidden ${className}`}>
        {!isLoaded && poster && (
          <motion.img
            initial={{ opacity: 1 }}
            animate={{ opacity: isLoaded ? 0 : 1 }}
            transition={{ duration: 0.3 }}
            src={poster}
            alt="Video thumbnail"
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        <iframe
          src={embedUrl}
          title="YouTube video player"
          frameBorder="0"
          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
          allowFullScreen
          onLoad={() => setIsLoaded(true)}
          className="w-full h-full"
        />
      </div>
    );
  }

  if (type === "vimeo") {
    const videoId = getVimeoId(videoUrl);
    const embedUrl = `https://player.vimeo.com/video/${videoId}?autoplay=${autoplay ? 1 : 0}&loop=${loop ? 1 : 0}&muted=${muted ? 1 : 0}&controls=${controls ? 1 : 0}`;

    return (
      <div className={`relative w-full aspect-video bg-[#0a1c14] rounded-[16px] overflow-hidden ${className}`}>
        {!isLoaded && poster && (
          <motion.img
            initial={{ opacity: 1 }}
            animate={{ opacity: isLoaded ? 0 : 1 }}
            transition={{ duration: 0.3 }}
            src={poster}
            alt="Video thumbnail"
            className="absolute inset-0 w-full h-full object-cover"
          />
        )}
        <iframe
          src={embedUrl}
          title="Vimeo video player"
          frameBorder="0"
          allow="autoplay; fullscreen; picture-in-picture"
          allowFullScreen
          onLoad={() => setIsLoaded(true)}
          className="w-full h-full"
        />
      </div>
    );
  }

  // Direct video file (HTML5 video)
  return (
    <div className={`relative w-full aspect-video bg-[#0a1c14] rounded-[16px] overflow-hidden ${className}`}>
      <video
        src={videoUrl}
        poster={poster}
        autoPlay={autoplay}
        loop={loop}
        muted={muted}
        controls={controls}
        playsInline
        className="w-full h-full object-cover"
        onLoadedData={() => setIsLoaded(true)}
      >
        Your browser does not support the video tag.
      </video>
    </div>
  );
}
