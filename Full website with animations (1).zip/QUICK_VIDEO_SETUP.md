# 🎬 Quick Video Setup Guide

## ✅ What's Been Added

I've created **3 new video components** for your RGL MEDIA website:

1. **VideoPlayer.tsx** - For embedded YouTube/Vimeo/Direct videos
2. **BackgroundVideo.tsx** - For hero section background videos
3. **Updated VideoModal.tsx** - Now supports real video playback

## 🚀 Fastest Way to Add Videos (3 Steps)

### Step 1: Upload Your Videos
- **YouTube** (easiest): Upload to YouTube → Set as "Unlisted" → Copy URL
- **Vimeo** (professional): Upload to Vimeo → Copy URL
- **Direct files**: Place in `/public/videos/` folder

### Step 2: Update Your Video URLs

Open `/src/app/pages/Home.tsx` and find this line (~156):

```tsx
onClick={() =>
  setVideoModal({ isOpen: true, title: "RGL MEDIA Showreel", category: "Highlight Reel" })
}
```

Replace with:
```tsx
onClick={() =>
  setVideoModal({
    isOpen: true,
    title: "RGL MEDIA Showreel",
    category: "Highlight Reel",
    videoUrl: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID", // ← Your URL here
    videoType: "youtube" // ← youtube, vimeo, or direct
  })
}
```

### Step 3: Update the VideoModal Component

In the same file (~23), update the VideoModal:

```tsx
<VideoModal
  isOpen={videoModal.isOpen}
  onClose={() => setVideoModal({ isOpen: false, title: "", category: "", videoUrl: "", videoType: "youtube" })}
  videoTitle={videoModal.title}
  videoCategory={videoModal.category}
  videoUrl={videoModal.videoUrl} // ← Add this
  videoType={videoModal.videoType} // ← Add this
/>
```

And update the state (~9):
```tsx
const [videoModal, setVideoModal] = useState<{
  isOpen: boolean;
  title: string;
  category: string;
  videoUrl?: string; // ← Add this
  videoType?: "youtube" | "vimeo" | "direct"; // ← Add this
}>({
  isOpen: false,
  title: "",
  category: "",
  videoUrl: "", // ← Add this
  videoType: "youtube", // ← Add this
});
```

## 📖 Example URLs

**YouTube:**
```tsx
videoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
videoType: "youtube"
```

**Vimeo:**
```tsx
videoUrl: "https://vimeo.com/123456789"
videoType: "vimeo"
```

**Direct Video File:**
```tsx
videoUrl: "/videos/wedding-highlight.mp4"
videoType: "direct"
```

## 🎨 Advanced Options

### Option 1: Background Video in Hero Section
```tsx
import BackgroundVideo from "../components/BackgroundVideo";

<BackgroundVideo
  videoUrl="/videos/hero-bg.mp4"
  type="direct"
  overlay={true}
  overlayOpacity={0.7}
>
  {/* Your hero content */}
</BackgroundVideo>
```

### Option 2: Inline Video Player
```tsx
import VideoPlayer from "../components/VideoPlayer";

<VideoPlayer
  videoUrl="https://www.youtube.com/watch?v=YOUR_VIDEO_ID"
  type="youtube"
  controls={true}
/>
```

### Option 3: Video Gallery Grid
See `EXAMPLE_VIDEO_GALLERY.tsx` for complete implementation.

## 📝 Files Created

All new files are ready to use:

- ✅ `/src/app/components/VideoPlayer.tsx`
- ✅ `/src/app/components/BackgroundVideo.tsx`
- ✅ `/src/app/components/VideoModal.tsx` (updated)
- 📚 `/VIDEO_GUIDE.md` (full documentation)
- 📚 `/EXAMPLE_HOME_WITH_VIDEOS.tsx` (complete example)
- 📚 `/EXAMPLE_BACKGROUND_VIDEO.tsx` (background video examples)
- 📚 `/EXAMPLE_VIDEO_GALLERY.tsx` (gallery page template)

## 💡 Where to Add Your Real Videos

**Home Page** (`/src/app/pages/Home.tsx`):
- Line ~156: Hero video card
- Line ~440: Featured work videos (update works array)

**Work Page** (`/src/app/pages/Work.tsx`):
- Create a video gallery using `EXAMPLE_VIDEO_GALLERY.tsx`

**Weddings Page** (`/src/app/pages/Weddings.tsx`):
- Add wedding video portfolio

**Ads Page** (`/src/app/pages/Ads.tsx`):
- Add commercial video showcase

## 🎯 Recommended Next Steps

1. **Upload 1-2 videos** to YouTube as "Unlisted"
2. **Copy the URLs** from YouTube
3. **Update Home.tsx** with the URLs (lines mentioned above)
4. **Test the video modal** by clicking the play button
5. **Repeat for other pages** (Work, Weddings, Ads)

## ⚡ Video Optimization Tips

**For Background Videos:**
- Keep under 5MB
- Use 5-10 second loops
- Compress with HandBrake
- 1280x720 resolution is enough

**For Portfolio Videos:**
- Upload to YouTube/Vimeo for best performance
- Use high-quality thumbnails
- Keep titles descriptive
- Add descriptions for SEO

## 🆘 Troubleshooting

**Video not playing?**
- Check the URL is correct
- Make sure YouTube/Vimeo video is not private
- For direct files, ensure they're in `/public/videos/`

**Video modal shows placeholder?**
- You need to pass `videoUrl` and `videoType` props
- Check the examples in `EXAMPLE_HOME_WITH_VIDEOS.tsx`

**Background video not showing?**
- Check file path is correct
- Ensure video file exists in `/public/videos/`
- Try reducing overlay opacity to see if video is underneath

## 📞 Ready to Use!

All components are ready. Just add your video URLs and you're done! 🎉

For detailed examples, check:
- `VIDEO_GUIDE.md` - Complete documentation
- `EXAMPLE_HOME_WITH_VIDEOS.tsx` - Step-by-step Home page example
- `EXAMPLE_VIDEO_GALLERY.tsx` - Full gallery implementation
