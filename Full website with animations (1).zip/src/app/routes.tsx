import { createBrowserRouter } from "react-router";
import Root from "./Root";
import Home from "./pages/Home";
import Weddings from "./pages/Weddings";
import Ads from "./pages/Ads";
import About from "./pages/About";
import Contact from "./pages/Contact";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Root,
    children: [
      { index: true, Component: Home },
      { path: "ads", Component: Ads },
      { path: "weddings", Component: Weddings },
      { path: "about", Component: About },
      { path: "contact", Component: Contact },
    ],
  },
]);
