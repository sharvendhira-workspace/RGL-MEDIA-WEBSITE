import { motion } from "motion/react";
import { Link } from "react-router";
import { useState } from "react";

export default function Weddings() {
  const weddingPackages = [
    {
      name: "Essential",
      price: "₹75,000",
      features: [
        "5-7 minute highlight film",
        "Full ceremony coverage",
        "1 cinematographer",
        "Basic color grading",
        "Digital delivery",
      ],
    },
    {
      name: "Premium",
      price: "₹1,50,000",
      features: [
        "10-12 minute cinematic film",
        "Full day coverage",
        "2 cinematographers",
        "Advanced color grading",
        "Drone coverage",
        "Teaser film (2-3 min)",
        "Digital + USB delivery",
      ],
      popular: true,
    },
    {
      name: "Luxury",
      price: "₹2,50,000",
      features: [
        "15-20 minute feature film",
        "Multi-day coverage",
        "3 cinematographers",
        "Cinema-grade grading",
        "Extensive drone coverage",
        "Teaser + trailer films",
        "Pre-wedding shoot",
        "Premium packaging",
      ],
    },
  ];

  const galleryItems = [
    { title: "Priya & Arjun", location: "Mahabalipuram", year: "2024" },
    { title: "Divya & Karthik", location: "Chettinad", year: "2024" },
    { title: "Meera & Rajesh", location: "Coimbatore", year: "2023" },
    { title: "Anjali & Vinay", location: "Chennai", year: "2024" },
    { title: "Lakshmi & Arun", location: "Pondicherry", year: "2023" },
    { title: "Nithya & Suresh", location: "Ooty", year: "2024" },
  ];

  return (
    <div className="pt-[80px]">
      <HeroSection />
      <PackagesSection packages={weddingPackages} />
      <GallerySection items={galleryItems} />
      <ProcessSection />
      <CTASection />
    </div>
  );
}

function HeroSection() {
  return (
    <section className="relative bg-[#0b1f17] h-[600px] overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(135deg, rgb(11, 31, 23) 0%, rgb(19, 42, 33) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute bg-[rgba(200,169,91,0.08)] blur-[80px] left-[200px] rounded-full w-[600px] h-[600px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 h-full flex items-center">
        <div className="max-w-[800px]">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] tracking-[1.32px] mb-6"
          >
            ✦ WEDDING FILMS ✦
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.5 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[36px] md:text-[56px] lg:text-[72px] leading-[1.15] mb-6"
          >
            <p className="mb-0">
              <span className="text-[#f5f5f5]">Your Love Story,</span>
            </p>
            <p>
              <span className="text-[#e5b94c]">Told Cinematically.</span>
            </p>
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.9 }}
            className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[20px] leading-[32px] mb-8"
          >
            We don't just record your wedding — we create timeless films that capture the emotion,
            beauty, and magic of your special day.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.1 }}
          >
            <Link to="/contact">
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0px 12px 32px 0px rgba(200,169,91,0.5)" }}
                whileTap={{ scale: 0.95 }}
                className="bg-[#c8a95b] h-[56px] px-10 rounded-[28px] shadow-[0px_8px_24px_0px_rgba(200,169,91,0.4)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[15px] tracking-[0.45px]"
              >
                Book Your Wedding Film
              </motion.button>
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

interface PackagesSectionProps {
  packages: Array<{
    name: string;
    price: string;
    features: string[];
    popular?: boolean;
  }>;
}

function PackagesSection({ packages }: PackagesSectionProps) {
  return (
    <section className="relative bg-[#132a21] py-24 overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.05)] blur-[60px] left-1/2 -translate-x-1/2 rounded-full w-[500px] h-[500px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ PACKAGES ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Choose Your Package
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {packages.map((pkg, index) => (
            <motion.div
              key={pkg.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.05, y: -10 }}
              className={`relative backdrop-blur-[6px] bg-[rgba(14,36,27,0.7)] border ${
                pkg.popular ? "border-[#c8a95b]" : "border-[rgba(200,169,91,0.5)]"
              } overflow-hidden rounded-[20px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.4)] p-8`}
            >
              {pkg.popular && (
                <div className="absolute top-4 right-4 bg-[#c8a95b] px-3 py-1 rounded-full">
                  <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[10px] tracking-[0.6px]">
                    MOST POPULAR
                  </p>
                </div>
              )}

              <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[28px] mb-2">
                {pkg.name}
              </p>

              <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#c8a95b] text-[42px] mb-6">
                {pkg.price}
              </p>

              <div className="space-y-4 mb-8">
                {pkg.features.map((feature, i) => (
                  <div key={i} className="flex items-start gap-3">
                    <div className="bg-[#c8a95b] rounded-full w-[6px] h-[6px] mt-2 flex-shrink-0" />
                    <p className="font-['Inter:Regular',sans-serif] text-[#a7b3aa] text-[15px] leading-[24px]">
                      {feature}
                    </p>
                  </div>
                ))}
              </div>

              <Link to="/contact">
                <motion.button
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className={`w-full h-[48px] rounded-[24px] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[14px] tracking-[0.42px] ${
                    pkg.popular
                      ? "bg-[#c8a95b] text-[#0b1f17]"
                      : "bg-transparent border border-[rgba(200,169,91,0.7)] text-[#c8a95b]"
                  }`}
                >
                  Book Now
                </motion.button>
              </Link>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

interface GallerySectionProps {
  items: Array<{
    title: string;
    location: string;
    year: string;
  }>;
}

function GallerySection({ items }: GallerySectionProps) {
  const [hoveredIndex, setHoveredIndex] = useState<number | null>(null);

  return (
    <section className="relative bg-[#0b1f17] py-24 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(180deg, rgb(5, 15, 11) 0%, rgb(11, 31, 23) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ PORTFOLIO ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          Recent Weddings
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {items.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ scale: 1.05, y: -10 }}
              onHoverStart={() => setHoveredIndex(index)}
              onHoverEnd={() => setHoveredIndex(null)}
              className="bg-[#081711] border border-[rgba(200,169,91,0.5)] h-[400px] overflow-hidden rounded-[16px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.5)] relative cursor-pointer"
            >
              <div className="absolute inset-0 bg-gradient-to-b from-[#0a1c14] to-[#030a07]" />
              <div className="absolute left-0 right-0 bottom-0 h-[150px] bg-gradient-to-b from-transparent to-[rgba(3,9,6,0.95)]" />

              <motion.div
                animate={{
                  scale: hoveredIndex === index ? 1.2 : 1,
                  opacity: hoveredIndex === index ? 1 : 0.8,
                }}
                transition={{ duration: 0.3 }}
                className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[rgba(200,169,91,0.15)] border border-[rgba(200,169,91,0.7)] rounded-full w-[60px] h-[60px] flex items-center justify-center"
              >
                <div className="w-0 h-0 border-t-[10px] border-t-transparent border-l-[16px] border-l-[#c8a95b] border-b-[10px] border-b-transparent ml-1" />
              </motion.div>

              <div className="absolute bottom-6 left-6 right-6">
                <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#f5f5f5] text-[18px] mb-1">
                  {item.title}
                </p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[13px]">
                  {item.location} • {item.year}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function ProcessSection() {
  const steps = [
    {
      number: "01",
      title: "Consultation",
      description: "We discuss your vision, preferences, and wedding details",
    },
    {
      number: "02",
      title: "Planning",
      description: "We create a detailed filming schedule and shot list",
    },
    {
      number: "03",
      title: "Filming",
      description: "Our team captures every precious moment of your day",
    },
    {
      number: "04",
      title: "Post-Production",
      description: "We edit, color grade, and craft your cinematic film",
    },
    {
      number: "05",
      title: "Delivery",
      description: "You receive your finished film ready to cherish forever",
    },
  ];

  return (
    <section className="relative bg-[#132a21] py-24 overflow-hidden">
      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ OUR PROCESS ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] text-center mb-12 md:mb-16"
        >
          How We Work
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-5 gap-6">
          {steps.map((step, index) => (
            <motion.div
              key={step.number}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.1 }}
              whileHover={{ y: -10 }}
              className="relative"
            >
              <div className="bg-[rgba(200,169,91,0.1)] border border-[rgba(200,169,91,0.4)] rounded-[12px] p-6">
                <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#c8a95b] text-[36px] mb-3">
                  {step.number}
                </p>
                <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#f5f5f5] text-[16px] mb-2">
                  {step.title}
                </p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[13px] leading-[20px]">
                  {step.description}
                </p>
              </div>

              {index < steps.length - 1 && (
                <div className="hidden md:block absolute top-1/2 -right-3 w-6 h-px bg-[rgba(200,169,91,0.3)]" />
              )}
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  return (
    <section className="relative bg-[#0b1f17] py-24">
      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 text-center">
        <motion.div
          initial={{ opacity: 0, scale: 0.8 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="max-w-[800px] mx-auto"
        >
          <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] leading-[1.15] mb-6">
            Ready to Begin?
          </p>

          <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px] mb-10">
            Let's discuss your wedding and create something beautiful together.
          </p>

          <Link to="/contact">
            <motion.button
              whileHover={{ scale: 1.05, boxShadow: "0px 12px 40px 0px rgba(200,169,91,0.6)" }}
              whileTap={{ scale: 0.95 }}
              className="bg-[#c8a95b] h-[60px] px-12 rounded-[30px] shadow-[0px_8px_32px_0px_rgba(200,169,91,0.5)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[16px] tracking-[0.48px]"
            >
              Get in Touch
            </motion.button>
          </Link>
        </motion.div>
      </div>
    </section>
  );
}
