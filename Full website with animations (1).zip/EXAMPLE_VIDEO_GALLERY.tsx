// EXAMPLE: Complete Video Gallery Page
// Use this as a template for your Work, Weddings, or Ads pages

import { motion } from "motion/react";
import { useState } from "react";
import VideoPlayer from "../components/VideoPlayer";
import VideoModal from "../components/VideoModal";

export default function VideoGalleryExample() {
  const [videoModal, setVideoModal] = useState<{
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string;
    videoType?: "youtube" | "vimeo" | "direct";
  }>({
    isOpen: false,
    title: "",
    category: "",
    videoUrl: "",
    videoType: "youtube",
  });

  // Your video portfolio
  const videos = [
    {
      id: 1,
      title: "Cinematic Wedding Film",
      category: "Wedding",
      description: "A beautiful love story captured in Chennai",
      year: "2024",
      videoUrl: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID_1",
      videoType: "youtube" as const,
      thumbnail: "/images/wedding-thumb-1.jpg",
      duration: "3:45",
    },
    {
      id: 2,
      title: "Brand Launch Campaign",
      category: "Commercial",
      description: "Product launch video for tech startup",
      year: "2024",
      videoUrl: "https://vimeo.com/123456789",
      videoType: "vimeo" as const,
      thumbnail: "/images/commercial-thumb-1.jpg",
      duration: "2:30",
    },
    {
      id: 3,
      title: "Couple Pre-Wedding Shoot",
      category: "Wedding",
      description: "Romantic pre-wedding story",
      year: "2024",
      videoUrl: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID_2",
      videoType: "youtube" as const,
      thumbnail: "/images/wedding-thumb-2.jpg",
      duration: "4:20",
    },
    {
      id: 4,
      title: "Corporate Ad Film",
      category: "Commercial",
      description: "Brand storytelling for enterprise client",
      year: "2023",
      videoUrl: "/videos/corporate-ad.mp4",
      videoType: "direct" as const,
      thumbnail: "/images/commercial-thumb-2.jpg",
      duration: "1:45",
    },
  ];

  return (
    <div className="pt-[80px] bg-[#0b1f17] min-h-screen">
      {/* Header Section */}
      <section className="relative py-20 overflow-hidden">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage:
              "linear-gradient(180deg, rgb(11, 31, 23) 0%, rgb(5, 15, 11) 100%)",
          }}
        />

        <div className="relative max-w-[1440px] mx-auto px-20 text-center">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] tracking-[1.32px] mb-4"
          >
            ✦ OUR PORTFOLIO ✦
          </motion.p>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[72px] leading-[84px] mb-6"
          >
            Featured Films
          </motion.h1>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px] max-w-[600px] mx-auto"
          >
            Cinematic stories that capture emotion, beauty, and unforgettable moments
          </motion.p>
        </div>
      </section>

      {/* Video Grid */}
      <section className="relative py-20 bg-[#132a21]">
        <div className="max-w-[1440px] mx-auto px-20">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {videos.map((video, index) => (
              <VideoCard
                key={video.id}
                video={video}
                index={index}
                onPlay={() =>
                  setVideoModal({
                    isOpen: true,
                    title: video.title,
                    category: video.category,
                    videoUrl: video.videoUrl,
                    videoType: video.videoType,
                  })
                }
              />
            ))}
          </div>
        </div>
      </section>

      {/* Video Modal */}
      <VideoModal
        isOpen={videoModal.isOpen}
        onClose={() =>
          setVideoModal({
            isOpen: false,
            title: "",
            category: "",
            videoUrl: "",
            videoType: "youtube",
          })
        }
        videoTitle={videoModal.title}
        videoCategory={videoModal.category}
        videoUrl={videoModal.videoUrl}
        videoType={videoModal.videoType}
      />
    </div>
  );
}

// Video Card Component
interface VideoCardProps {
  video: {
    title: string;
    category: string;
    description: string;
    year: string;
    thumbnail: string;
    duration: string;
  };
  index: number;
  onPlay: () => void;
}

function VideoCard({ video, index, onPlay }: VideoCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ scale: 1.02, y: -10 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={onPlay}
      className="backdrop-blur-[6px] bg-[rgba(14,36,27,0.7)] border border-[rgba(200,169,91,0.6)] overflow-hidden rounded-[20px] shadow-[0px_20px_50px_-10px_rgba(0,0,0,0.5)] cursor-pointer"
    >
      {/* Video Thumbnail */}
      <div className="relative h-[320px] bg-gradient-to-b from-[#0a1c14] to-[#030a07] overflow-hidden">
        {/* Thumbnail Image (replace with real image) */}
        <div className="absolute inset-0 bg-[#0a1c14]" />

        {/* Category Badge */}
        <div className="absolute top-4 left-4 bg-[rgba(11,31,23,0.9)] border border-[rgba(200,169,91,0.4)] h-[28px] px-3 rounded-[14px] flex items-center z-10">
          <p className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[10px] tracking-[0.6px]">
            {video.category}
          </p>
        </div>

        {/* Duration Badge */}
        <div className="absolute top-4 right-4 bg-[rgba(11,31,23,0.9)] border border-[rgba(200,169,91,0.4)] h-[28px] px-3 rounded-[14px] flex items-center z-10">
          <p className="font-['Inter:Medium',sans-serif] font-medium text-[#a7b3aa] text-[10px] tracking-[0.6px]">
            {video.duration}
          </p>
        </div>

        {/* Play Button */}
        <motion.div
          animate={{
            scale: isHovered ? 1.15 : 1,
            opacity: isHovered ? 1 : 0.9,
          }}
          transition={{ duration: 0.3 }}
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[rgba(200,169,91,0.15)] border-2 border-[rgba(200,169,91,0.8)] rounded-full w-[64px] h-[64px] flex items-center justify-center z-10"
        >
          <div className="w-0 h-0 border-t-[12px] border-t-transparent border-l-[20px] border-l-[#c8a95b] border-b-[12px] border-b-transparent ml-1" />
        </motion.div>

        {/* Gradient Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-[rgba(3,9,6,0.9)] via-transparent to-transparent" />
      </div>

      {/* Video Info */}
      <div className="p-6">
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#f5f5f5] text-[20px] mb-2">
          {video.title}
        </p>
        <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[14px] leading-[22px] mb-3">
          {video.description}
        </p>
        <div className="flex items-center gap-3">
          <div className="bg-[#c8a95b] h-[2px] w-[24px]" />
          <p className="font-['Inter:Light',sans-serif] font-light text-[rgba(200,169,91,0.8)] text-[12px] tracking-[0.48px]">
            {video.year}
          </p>
        </div>
      </div>
    </motion.div>
  );
}

/*
 * ALTERNATIVE LAYOUT: Masonry Grid (Pinterest-style)
 */
export function VideoGalleryMasonry() {
  // Install: pnpm add react-responsive-masonry
  // import Masonry, { ResponsiveMasonry } from "react-responsive-masonry";

  return (
    <div className="max-w-[1440px] mx-auto px-20">
      {/* <ResponsiveMasonry columnsCountBreakPoints={{ 350: 1, 750: 2, 900: 3 }}>
        <Masonry gutter="20px">
          {videos.map((video) => (
            <VideoCard key={video.id} video={video} />
          ))}
        </Masonry>
      </ResponsiveMasonry> */}
    </div>
  );
}

/*
 * ALTERNATIVE LAYOUT: Inline Video Players (Auto-play on view)
 */
export function VideoGalleryInline() {
  const videos = [
    { id: 1, url: "https://www.youtube.com/watch?v=VIDEO_ID", type: "youtube" as const },
    { id: 2, url: "https://vimeo.com/123456", type: "vimeo" as const },
  ];

  return (
    <div className="max-w-[1440px] mx-auto px-20 space-y-8">
      {videos.map((video, index) => (
        <motion.div
          key={video.id}
          initial={{ opacity: 0, y: 50 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: index * 0.1 }}
        >
          <VideoPlayer videoUrl={video.url} type={video.type} controls={true} />
        </motion.div>
      ))}
    </div>
  );
}
