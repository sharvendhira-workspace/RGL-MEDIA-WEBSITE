import { Link, useLocation } from "react-router";
import { motion } from "motion/react";
import { useState, useEffect } from "react";
import imgScreenshot from "../../imports/Group2/f10029e071be64d59c8e4fcf54bd4f0b0b33ea53.png";
import imgBackground from "../../imports/Group2/fc40e9fe3439f465deab18fb935f67e9375e880f.png";

export default function Navbar() {
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  useEffect(() => {
    setMobileOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navItems = [
    { name: "Home", path: "/" },
    { name: "Ads", path: "/ads" },
    { name: "Weddings", path: "/weddings" },
    { name: "About", path: "/about" },
    { name: "Contact", path: "/contact" },
  ];

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
      className={`fixed top-0 left-0 right-0 z-50 backdrop-blur-[10px] transition-all duration-300 ${
        scrolled ? "bg-[rgba(11,31,23,0.95)] shadow-lg" : "bg-[rgba(11,31,23,0.75)]"
      }`}
    >
      <div className="max-w-[1440px] mx-auto relative h-[80px]">
        <div className="absolute bg-[rgba(200,169,91,0.3)] h-px left-0 right-0 bottom-0" />

        <div className="flex items-center justify-between h-full px-4 md:px-8">
          <Link
            to="/"
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            className="relative z-10"
          >
            <motion.div
              whileHover={{ scale: 1.05 }}
              className="relative w-[96px] h-[42px] md:w-[124px] md:h-[54.4px]"
            >
              <img
                alt="RGL MEDIA"
                className="absolute inset-0 w-full h-full"
                src={imgScreenshot}
              />
              <img
                alt=""
                className="absolute left-[5.6px] top-[5.6px] w-[84.8px] h-[30.2px] md:left-[7.25px] md:top-[7.25px] md:w-[110.25px] md:h-[39.16px] object-cover"
                src={imgBackground}
              />
            </motion.div>
          </Link>

          <div className="hidden lg:flex items-center gap-8">
            {navItems.map((item, index) => {
              const isActive = location.pathname === item.path;
              return (
                <motion.div
                  key={item.path}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1, duration: 0.4 }}
                >
                  <Link
                    to={item.path}
                    onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                    className={`font-['Inter:Medium',sans-serif] font-medium text-[14px] tracking-[0.7px] transition-colors relative group ${
                      isActive ? "text-[#c8a95b]" : "text-[#a7b3aa] hover:text-[#c8a95b]"
                    }`}
                  >
                    {item.name}
                    {isActive && (
                      <motion.div
                        layoutId="activeNav"
                        className="absolute -bottom-[28px] left-0 right-0 h-[2px] bg-[#c8a95b]"
                      />
                    )}
                  </Link>
                </motion.div>
              );
            })}
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.6, duration: 0.4 }}
            className="hidden md:block"
          >
            <Link to="/contact">
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0px 0px 24px 0px rgba(200,169,91,0.5)" }}
                whileTap={{ scale: 0.95 }}
                className="bg-[#c8a95b] h-[40px] px-6 rounded-[20px] shadow-[0px_0px_18px_0px_rgba(200,169,91,0.35)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[12px] tracking-[0.36px]"
              >
                Book a Shoot
              </motion.button>
            </Link>
          </motion.div>

          <button
            aria-label="Toggle menu"
            onClick={() => setMobileOpen((v) => !v)}
            className="lg:hidden w-10 h-10 flex flex-col items-center justify-center gap-[5px] text-[#c8a95b]"
          >
            <span className={`block w-6 h-[2px] bg-current transition-transform ${mobileOpen ? "translate-y-[7px] rotate-45" : ""}`} />
            <span className={`block w-6 h-[2px] bg-current transition-opacity ${mobileOpen ? "opacity-0" : ""}`} />
            <span className={`block w-6 h-[2px] bg-current transition-transform ${mobileOpen ? "-translate-y-[7px] -rotate-45" : ""}`} />
          </button>
        </div>

        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            className="lg:hidden absolute top-full left-0 right-0 bg-[rgba(11,31,23,0.98)] border-t border-[rgba(200,169,91,0.3)] px-4 py-4 flex flex-col gap-4"
          >
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => {
                    window.scrollTo({ top: 0, behavior: "smooth" });
                    setMobileOpen(false);
                  }}
                  className={`font-['Inter:Medium',sans-serif] font-medium text-[15px] tracking-[0.7px] ${
                    isActive ? "text-[#c8a95b]" : "text-[#a7b3aa]"
                  }`}
                >
                  {item.name}
                </Link>
              );
            })}
            <Link
              to="/contact"
              onClick={() => setMobileOpen(false)}
              className="bg-[#c8a95b] h-[40px] px-6 rounded-[20px] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[12px] tracking-[0.36px] flex items-center justify-center"
            >
              Book a Shoot
            </Link>
          </motion.div>
        )}
      </div>
    </motion.nav>
  );
}
