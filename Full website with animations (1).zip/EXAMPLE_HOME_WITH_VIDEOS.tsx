// EXAMPLE: How to update Home.tsx to use real videos
// Copy the relevant parts to your actual /src/app/pages/Home.tsx

import { motion } from "motion/react";
import { Link } from "react-router";
import { useState } from "react";
import VideoModal from "../components/VideoModal";

export default function HomeExample() {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);
  const [videoModal, setVideoModal] = useState<{
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string; // Add this
    videoType?: "youtube" | "vimeo" | "direct"; // Add this
  }>({
    isOpen: false,
    title: "",
    category: "",
    videoUrl: "", // Add this
    videoType: "youtube", // Add this
  });

  return (
    <div className="pt-[80px]">
      {/* Pass setVideoModal to components that need it */}
      <HeroSection setVideoModal={setVideoModal} />
      <FeaturedWork setVideoModal={setVideoModal} />

      {/* Updated VideoModal with video support */}
      <VideoModal
        isOpen={videoModal.isOpen}
        onClose={() =>
          setVideoModal({
            isOpen: false,
            title: "",
            category: "",
            videoUrl: "",
            videoType: "youtube",
          })
        }
        videoTitle={videoModal.title}
        videoCategory={videoModal.category}
        videoUrl={videoModal.videoUrl} // Add this
        videoType={videoModal.videoType} // Add this
      />
    </div>
  );
}

// EXAMPLE: Update the VideoCard component
interface VideoCardProps {
  setVideoModal: (modal: {
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string;
    videoType?: "youtube" | "vimeo" | "direct";
  }) => void;
}

function VideoCard({ setVideoModal }: VideoCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -10 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() =>
        setVideoModal({
          isOpen: true,
          title: "RGL MEDIA Showreel 2024",
          category: "Highlight Reel",
          // 👇 ADD YOUR REAL VIDEO URL HERE
          videoUrl: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID",
          videoType: "youtube", // or "vimeo" or "direct"
        })
      }
      className="backdrop-blur-[8px] bg-[rgba(19,42,33,0.45)] border border-[rgba(200,169,91,0.6)] h-[660px] overflow-hidden rounded-[24px] shadow-[0px_0px_60px_0px_rgba(200,169,91,0.1),0px_40px_80px_-10px_rgba(0,0,0,0.5)] w-[500px] relative cursor-pointer"
    >
      {/* Your existing video card UI */}
    </motion.div>
  );
}

// EXAMPLE: Update the WorkCard component
interface WorkCardProps {
  work: {
    title: string;
    category: string;
    year: string;
    height: string;
    width: string;
    videoUrl: string; // Add this to your work objects
    videoType: "youtube" | "vimeo" | "direct"; // Add this
  };
  setVideoModal: (modal: {
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string;
    videoType?: "youtube" | "vimeo" | "direct";
  }) => void;
}

function WorkCard({ work, setVideoModal }: WorkCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      whileHover={{ scale: 1.03, y: -10 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() =>
        setVideoModal({
          isOpen: true,
          title: work.title,
          category: work.category,
          // 👇 USE THE VIDEO URL FROM YOUR WORK OBJECT
          videoUrl: work.videoUrl,
          videoType: work.videoType,
        })
      }
      className="cursor-pointer"
    >
      {/* Your existing work card UI */}
    </motion.div>
  );
}

// EXAMPLE: Update your works array
interface HeroSectionProps {
  setVideoModal: (modal: {
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string;
    videoType?: "youtube" | "vimeo" | "direct";
  }) => void;
}

function HeroSection({ setVideoModal }: HeroSectionProps) {
  return <div>{/* Your hero section */}</div>;
}

interface FeaturedWorkProps {
  setVideoModal: (modal: {
    isOpen: boolean;
    title: string;
    category: string;
    videoUrl?: string;
    videoType?: "youtube" | "vimeo" | "direct";
  }) => void;
}

function FeaturedWork({ setVideoModal }: FeaturedWorkProps) {
  // 👇 ADD VIDEO URLS TO YOUR WORKS
  const works = [
    {
      title: "Wedding Highlight",
      category: "Wedding Film",
      year: "2024",
      height: "320px",
      width: "420px",
      videoUrl: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID_1", // Add real URL
      videoType: "youtube" as const,
    },
    {
      title: "Brand Campaign",
      category: "Commercial Ad",
      year: "2024",
      height: "460px",
      width: "340px",
      videoUrl: "https://vimeo.com/123456789", // Add real URL
      videoType: "vimeo" as const,
    },
    {
      title: "Couple Story",
      category: "Wedding Film",
      year: "2023",
      height: "220px",
      width: "510px",
      videoUrl: "/videos/couple-story.mp4", // Or use local video
      videoType: "direct" as const,
    },
  ];

  return (
    <section className="relative bg-[#0b1f17] py-20">
      <div className="max-w-[1440px] mx-auto px-20">
        <div className="grid grid-cols-12 gap-5">
          {works.map((work, index) => (
            <WorkCard key={work.title} work={work} setVideoModal={setVideoModal} />
          ))}
        </div>
      </div>
    </section>
  );
}

/*
 * QUICK SETUP STEPS:
 *
 * 1. Upload your videos to YouTube or Vimeo
 * 2. Get the video URLs
 * 3. Update the videoUrl in setVideoModal calls
 * 4. Update the videoType ("youtube", "vimeo", or "direct")
 * 5. Update the works array with your real video URLs
 *
 * EXAMPLE URLs:
 * - YouTube: "https://www.youtube.com/watch?v=dQw4w9WgXcQ"
 * - Vimeo: "https://vimeo.com/123456789"
 * - Direct: "/videos/my-video.mp4" (place file in /public/videos/)
 */
