import { motion } from "motion/react";
import { ReactNode } from "react";

interface BackgroundVideoProps {
  videoUrl: string;
  type?: "youtube" | "vimeo" | "direct";
  overlay?: boolean;
  overlayOpacity?: number;
  overlayColor?: string;
  children?: ReactNode;
  className?: string;
}

export default function BackgroundVideo({
  videoUrl,
  type = "direct",
  overlay = true,
  overlayOpacity = 0.5,
  overlayColor = "#0b1f17",
  children,
  className = "",
}: BackgroundVideoProps) {
  // Extract video ID from YouTube URL
  const getYouTubeId = (url: string) => {
    const match = url.match(/(?:youtube\.com\/(?:[^\/]+\/.+\/|(?:v|e(?:mbed)?)\/|.*[?&]v=)|youtu\.be\/)([^"&?\/\s]{11})/);
    return match ? match[1] : url;
  };

  // Extract video ID from Vimeo URL
  const getVimeoId = (url: string) => {
    const match = url.match(/(?:vimeo\.com\/)(\d+)/);
    return match ? match[1] : url;
  };

  return (
    <div className={`relative w-full h-full overflow-hidden ${className}`}>
      {/* Video Background */}
      {type === "youtube" && (
        <div className="absolute inset-0 w-full h-full">
          <iframe
            src={`https://www.youtube.com/embed/${getYouTubeId(videoUrl)}?autoplay=1&mute=1&loop=1&controls=0&showinfo=0&rel=0&modestbranding=1&playsinline=1&playlist=${getYouTubeId(videoUrl)}`}
            title="Background video"
            frameBorder="0"
            allow="autoplay; encrypted-media"
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[300%] h-[300%] pointer-events-none"
          />
        </div>
      )}

      {type === "vimeo" && (
        <div className="absolute inset-0 w-full h-full">
          <iframe
            src={`https://player.vimeo.com/video/${getVimeoId(videoUrl)}?autoplay=1&muted=1&loop=1&background=1&controls=0`}
            title="Background video"
            frameBorder="0"
            allow="autoplay; fullscreen"
            className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-full pointer-events-none"
          />
        </div>
      )}

      {type === "direct" && (
        <video
          src={videoUrl}
          autoPlay
          loop
          muted
          playsInline
          className="absolute inset-0 w-full h-full object-cover"
        >
          Your browser does not support the video tag.
        </video>
      )}

      {/* Overlay */}
      {overlay && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: overlayOpacity }}
          transition={{ duration: 0.5 }}
          className="absolute inset-0 z-10"
          style={{ backgroundColor: overlayColor }}
        />
      )}

      {/* Content */}
      <div className="relative z-20 w-full h-full">
        {children}
      </div>
    </div>
  );
}
