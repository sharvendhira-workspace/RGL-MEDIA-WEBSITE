import { motion } from "motion/react";
import { Instagram, Youtube, Linkedin } from "lucide-react";

export default function Footer() {
  const socialLinks = [
    { name: "Instagram", Icon: Instagram, url: "https://instagram.com/rglmedia" },
    { name: "LinkedIn", Icon: Linkedin, url: "https://linkedin.com/company/rglmedia" },
    { name: "YouTube", Icon: Youtube, url: "https://youtube.com/@rglmedia" },
  ];

  return (
    <footer className="bg-[#050e0a] relative overflow-hidden">
      <div className="absolute bg-[rgba(200,169,91,0.25)] h-px left-0 right-0 top-0" />

      <div className="max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 py-12">
        {/* Top: contact info and social icons side by side */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="flex flex-col md:flex-row md:items-center md:justify-between gap-6 mb-8"
        >
          <div className="flex flex-wrap justify-center md:justify-start gap-x-8 gap-y-2">
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#a7b3aa]">
              📧 <span className="text-white">rglmediaa@gmail.com</span>
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#a7b3aa]">
              📞 <span className="text-white">+91 98426 12090</span>
            </p>
            <p className="font-['Inter:Regular',sans-serif] text-[14px] text-[#a7b3aa]">
              📍 <span className="text-white">Chennai, Coimbatore, Salem</span>
            </p>
          </div>

          {/* Social icons */}
          <div className="flex justify-center md:justify-end items-center" style={{ gap: "20px" }}>
            {socialLinks.map(({ name, Icon, url }, index) => (
              <motion.a
                key={name}
                href={url}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={name}
                initial={{ opacity: 0, scale: 0 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: 0.1 + index * 0.1, duration: 0.4 }}
                whileHover={{
                  scale: 1.1,
                  filter: "drop-shadow(0 0 8px rgba(200,169,91,0.8))",
                }}
                whileTap={{ scale: 0.95 }}
                className="text-[#c8a95b]"
              >
                <Icon size={24} />
              </motion.a>
            ))}
          </div>
        </motion.div>

        {/* Bottom: Copyright */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Light',sans-serif] font-light text-[12px] text-[rgba(167,179,170,0.7)] text-center"
        >
          © 2026 RGL MEDIA. All rights reserved.
        </motion.p>
      </div>
    </footer>
  );
}
