# Video Integration Guide for RGL MEDIA

This guide shows you how to add videos to your website in multiple ways.

## 🎬 Available Video Components

### 1. **VideoPlayer** - For embedded videos
Located at: `/src/app/components/VideoPlayer.tsx`

**Supported types:**
- YouTube embeds
- Vimeo embeds
- Direct video files (MP4, WebM, etc.)

### 2. **BackgroundVideo** - For background videos
Located at: `/src/app/components/BackgroundVideo.tsx`

**Features:**
- Full-screen background videos
- Customizable overlay
- Auto-play, loop, muted

### 3. **VideoModal** - For video popups
Located at: `/src/app/components/VideoModal.tsx`

**Updated to support:**
- YouTube/Vimeo embeds
- Direct video files

---

## 📖 How to Use

### Method 1: YouTube Videos

```tsx
import VideoPlayer from "../components/VideoPlayer";

<VideoPlayer
  videoUrl="https://www.youtube.com/watch?v=dQw4w9WgXcQ"
  type="youtube"
  controls={true}
/>
```

**With VideoModal:**
```tsx
setVideoModal({
  isOpen: true,
  title: "Wedding Highlight",
  category: "Wedding Film",
  videoUrl: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID",
  videoType: "youtube"
})
```

### Method 2: Vimeo Videos

```tsx
import VideoPlayer from "../components/VideoPlayer";

<VideoPlayer
  videoUrl="https://vimeo.com/123456789"
  type="vimeo"
  controls={true}
/>
```

**With VideoModal:**
```tsx
setVideoModal({
  isOpen: true,
  title: "Brand Campaign",
  category: "Commercial Ad",
  videoUrl: "https://vimeo.com/123456789",
  videoType: "vimeo"
})
```

### Method 3: Direct Video Files

First, place your video file in `/public/videos/` folder, then:

```tsx
import VideoPlayer from "../components/VideoPlayer";

<VideoPlayer
  videoUrl="/videos/wedding-highlight.mp4"
  type="direct"
  poster="/images/video-thumbnail.jpg"
  controls={true}
  autoplay={false}
  loop={false}
/>
```

### Method 4: Background Videos (Hero Sections)

```tsx
import BackgroundVideo from "../components/BackgroundVideo";

<BackgroundVideo
  videoUrl="/videos/hero-background.mp4"
  type="direct"
  overlay={true}
  overlayOpacity={0.6}
  overlayColor="#0b1f17"
>
  <div className="flex items-center justify-center h-full">
    <h1>Your Content Here</h1>
  </div>
</BackgroundVideo>
```

---

## 🎯 Common Use Cases

### Use Case 1: Update Home Page Video Card

Update `/src/app/pages/Home.tsx`:

```tsx
// In the VideoCard click handler:
onClick={() =>
  setVideoModal({
    isOpen: true,
    title: "RGL MEDIA Showreel",
    category: "Highlight Reel",
    videoUrl: "https://www.youtube.com/watch?v=YOUR_VIDEO_ID", // Add this
    videoType: "youtube" // Add this
  })
}
```

### Use Case 2: Add Background Video to Hero Section

```tsx
import BackgroundVideo from "../components/BackgroundVideo";

function HeroSection({ setVideoModal }: HeroSectionProps) {
  return (
    <BackgroundVideo
      videoUrl="/videos/hero-bg.mp4"
      type="direct"
      overlay={true}
      overlayOpacity={0.7}
      className="h-[900px]"
    >
      <section className="relative h-full">
        {/* Your existing hero content */}
      </section>
    </BackgroundVideo>
  );
}
```

### Use Case 3: Video Gallery Grid

```tsx
const videos = [
  {
    title: "Wedding Highlight",
    url: "https://www.youtube.com/watch?v=VIDEO_ID_1",
    type: "youtube",
    thumbnail: "/images/thumb1.jpg"
  },
  {
    title: "Brand Campaign",
    url: "https://vimeo.com/123456789",
    type: "vimeo",
    thumbnail: "/images/thumb2.jpg"
  }
];

<div className="grid grid-cols-3 gap-6">
  {videos.map((video) => (
    <VideoPlayer
      key={video.title}
      videoUrl={video.url}
      type={video.type}
      poster={video.thumbnail}
    />
  ))}
</div>
```

---

## 💡 Tips & Best Practices

### For YouTube Videos:
1. Get the video ID from the URL: `https://www.youtube.com/watch?v=VIDEO_ID`
2. The component automatically extracts the ID
3. Use unlisted videos for client work

### For Vimeo Videos:
1. Get the video ID from the URL: `https://vimeo.com/VIDEO_ID`
2. Vimeo is recommended for professional/client videos
3. Better privacy controls than YouTube

### For Direct Video Files:
1. Place videos in `/public/videos/` folder
2. Recommended formats: MP4 (H.264), WebM
3. Optimize file size (use tools like HandBrake)
4. Keep files under 10MB for web performance
5. Use poster images for better UX

### For Background Videos:
1. Keep files small (under 5MB)
2. Use short loops (5-10 seconds)
3. Always mute background videos
4. Provide overlay for text readability

---

## 🚀 Quick Start Example

Create `/public/videos/` folder and add a video file, then update any page:

```tsx
import { useState } from "react";
import VideoPlayer from "../components/VideoPlayer";
import VideoModal from "../components/VideoModal";

export default function Work() {
  const [videoModal, setVideoModal] = useState({
    isOpen: false,
    title: "",
    category: "",
    videoUrl: "",
    videoType: "youtube" as "youtube" | "vimeo" | "direct"
  });

  return (
    <div>
      {/* Inline Video */}
      <VideoPlayer
        videoUrl="https://www.youtube.com/watch?v=YOUR_VIDEO_ID"
        type="youtube"
      />

      {/* Click to open modal */}
      <button
        onClick={() =>
          setVideoModal({
            isOpen: true,
            title: "Our Latest Work",
            category: "Showreel",
            videoUrl: "https://vimeo.com/123456789",
            videoType: "vimeo"
          })
        }
      >
        Watch Video
      </button>

      <VideoModal
        isOpen={videoModal.isOpen}
        onClose={() => setVideoModal({ ...videoModal, isOpen: false })}
        videoTitle={videoModal.title}
        videoCategory={videoModal.category}
        videoUrl={videoModal.videoUrl}
        videoType={videoModal.videoType}
      />
    </div>
  );
}
```

---

## 📝 Next Steps

1. **Upload your videos** to YouTube or Vimeo (recommended)
2. **Get the video URLs** from your uploads
3. **Update the Home page** video cards with real URLs
4. **Add videos to Work/Weddings/Ads pages**
5. **Optimize** video thumbnails for faster loading

Need help? Check the example components or modify `/src/app/pages/Home.tsx` to see working examples!
