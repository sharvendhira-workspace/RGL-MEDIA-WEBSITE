import { motion } from "motion/react";
import { Link } from "react-router";
import { useState } from "react";
import img4A75D9C319F8E0909B19B3Fd8274F4461 from "../../imports/Group2/93a881c92edceb9cf38f23fcc5d1d230c216f7fc.png";
import VideoModal from "../components/VideoModal";

export default function Home() {
  const [hoveredCard, setHoveredCard] = useState<string | null>(null);
  const [videoModal, setVideoModal] = useState<{ isOpen: boolean; title: string; category: string }>({
    isOpen: false,
    title: "",
    category: "",
  });

  return (
    <div className="pt-[80px]">
      <HeroSection setVideoModal={setVideoModal} />
      <ServicesSection hoveredCard={hoveredCard} setHoveredCard={setHoveredCard} />
      <FeaturedWork setVideoModal={setVideoModal} />
      <Testimonials />
      <AboutSection />
      <CTASection />
      <VideoModal
        isOpen={videoModal.isOpen}
        onClose={() => setVideoModal({ isOpen: false, title: "", category: "" })}
        videoTitle={videoModal.title}
        videoCategory={videoModal.category}
      />
    </div>
  );
}

interface HeroSectionProps {
  setVideoModal: (modal: { isOpen: boolean; title: string; category: string }) => void;
}

function HeroSection({ setVideoModal }: HeroSectionProps) {
  return (
    <section className="relative bg-[#0b1f17] min-h-[700px] md:h-[900px] overflow-hidden py-12 md:py-0">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(32.0054deg, rgb(11, 31, 23) 28.571%, rgb(19, 42, 33) 71.429%, rgb(5, 15, 11) 100%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5 }}
        className="absolute bg-[rgba(200,169,91,0.06)] blur-[60px] left-[-80px] rounded-[250px] w-[500px] h-[500px] top-[200px]"
      />
      <motion.div
        initial={{ opacity: 0, scale: 0.8 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 1.5, delay: 0.2 }}
        className="absolute bg-[rgba(200,169,91,0.04)] blur-[50px] left-[1050px] rounded-[225px] w-[450px] h-[450px] top-[150px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 h-full flex flex-col lg:flex-row items-center gap-10">
        <div className="flex-1 w-full">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.7 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[44px] sm:text-[60px] lg:text-[83px] leading-[1.1] lg:leading-[96px] mb-2"
          >
            <p className="mb-0">
              <span className="text-[#f5f5f5]">At </span>
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[44px] sm:text-[60px] lg:text-[83px] leading-[1.1] lg:leading-[96px] mb-2"
          >
            <p className="mb-0">
              <span className="text-[#e5b94c]">RGL MEDIA</span>
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.9 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[44px] sm:text-[60px] lg:text-[83px] leading-[1.1] lg:leading-[96px] mb-2"
          >
            <p className="mb-0">
              <span className="text-[#f5f5f5]">Creativity meets</span>
            </p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.0 }}
            className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[44px] sm:text-[60px] lg:text-[83px] leading-[1.1] lg:leading-[96px] mb-8"
          >
            <p>
              <span className="text-[#e5b94c]">Strategy.</span>
            </p>
          </motion.div>

          <motion.p
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1.1 }}
            className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px] leading-[30px] max-w-[440px] mb-8"
          >
            We Create Stories That Define Modern Media
          </motion.p>

          <motion.div
            initial={{ scaleX: 0 }}
            animate={{ scaleX: 1 }}
            transition={{ duration: 0.6, delay: 1.3 }}
            className="bg-[#c8a95b] h-[2px] w-[50px] mb-6 origin-left"
          />

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 1.5 }}
            className="flex gap-4"
          >
            <Link to="/ads">
              <motion.button
                whileHover={{ scale: 1.05, boxShadow: "0px 12px 32px 0px rgba(200,169,91,0.5)" }}
                whileTap={{ scale: 0.95 }}
                className="bg-[#c8a95b] h-[52px] px-8 rounded-[26px] shadow-[0px_8px_24px_0px_rgba(200,169,91,0.4)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[14px] tracking-[0.42px]"
              >
                View Our Work
              </motion.button>
            </Link>
            <Link to="/contact">
              <motion.button
                whileHover={{ scale: 1.05, borderColor: "rgba(200,169,91,1)" }}
                whileTap={{ scale: 0.95 }}
                className="bg-transparent border border-[rgba(200,169,91,0.7)] h-[52px] px-8 rounded-[26px] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#c8a95b] text-[14px] tracking-[0.42px] transition-colors"
              >
                Book a Shoot
              </motion.button>
            </Link>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, x: 100, rotateY: -20 }}
          animate={{ opacity: 1, x: 0, rotateY: 0 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="relative"
        >
          <VideoCard setVideoModal={setVideoModal} />
        </motion.div>
      </div>
    </section>
  );
}

interface VideoCardProps {
  setVideoModal: (modal: { isOpen: boolean; title: string; category: string }) => void;
}

function VideoCard({ setVideoModal }: VideoCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -10 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() =>
        setVideoModal({ isOpen: true, title: "RGL MEDIA Showreel", category: "Highlight Reel" })
      }
      className="backdrop-blur-[8px] bg-[rgba(19,42,33,0.45)] border border-[rgba(200,169,91,0.6)] h-[400px] sm:h-[520px] lg:h-[660px] overflow-hidden rounded-[24px] shadow-[0px_0px_60px_0px_rgba(200,169,91,0.1),0px_40px_80px_-10px_rgba(0,0,0,0.5)] w-full max-w-[500px] lg:w-[500px] relative cursor-pointer mx-auto"
    >
      <div className="absolute bg-gradient-to-b from-[#081711] inset-[23px] bottom-auto h-[calc(100%-46px)] max-h-[520px] rounded-[16px] to-[#030a07] flex items-center justify-center">
        <motion.div
          animate={{ scale: isHovered ? 1.1 : 1 }}
          transition={{ duration: 0.3 }}
          className="absolute bg-[rgba(200,169,91,0.2)] border border-[rgba(200,169,91,0.8)] rounded-full w-[80px] h-[80px] flex items-center justify-center"
        >
          <div className="w-0 h-0 border-t-[12px] border-t-transparent border-l-[20px] border-l-[#c8a95b] border-b-[12px] border-b-transparent ml-1" />
        </motion.div>
      </div>
      <div className="absolute h-[666px] left-[-17px] top-[-1px] w-[532px] pointer-events-none">
        <img
          alt=""
          className="absolute h-[106.51%] left-[-3.42%] max-w-none top-[-6.51%] w-[106.67%]"
          src={img4A75D9C319F8E0909B19B3Fd8274F4461}
        />
      </div>
    </motion.div>
  );
}

interface ServicesSectionProps {
  hoveredCard: string | null;
  setHoveredCard: (card: string | null) => void;
}

function ServicesSection({ hoveredCard, setHoveredCard }: ServicesSectionProps) {
  return (
    <section className="relative bg-[#132a21] py-20 overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.04)] blur-[50px] left-[520px] rounded-[200px] w-[400px] h-[400px] top-[100px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ OUR SERVICES ✦
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[34px] md:text-[48px] lg:text-[56px] leading-[1.15] text-[#f5f5f5] text-center mb-16"
        >
          <p className="mb-0">Two Specialties.</p>
          <p>One Vision.</p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-[1280px] mx-auto">
          <ServiceCard
            type="ads"
            icon="🎬"
            title="Commercial Ads"
            description="Brand stories that move and convert."
            features={["Brand Campaigns", "Product Shoots", "Social Media Reels", "Promotional Videos"]}
            buttonText="View Ad Work"
            buttonLink="/ads"
            isHovered={hoveredCard === "ads"}
            setHovered={setHoveredCard}
          />
          <ServiceCard
            type="wedding"
            icon="💍"
            title="Wedding Films"
            description="Timeless stories, told cinematically."
            features={["Teaser Films", "Couple Shoots", "Drone Coverage", "Cinematic Storytelling"]}
            buttonText="Explore Films"
            buttonLink="/weddings"
            isHovered={hoveredCard === "wedding"}
            setHovered={setHoveredCard}
            filled
          />
        </div>
      </div>
    </section>
  );
}

interface ServiceCardProps {
  type: string;
  icon: string;
  title: string;
  description: string;
  features: string[];
  buttonText: string;
  buttonLink: string;
  isHovered: boolean;
  setHovered: (type: string | null) => void;
  filled?: boolean;
}

function ServiceCard({
  type,
  icon,
  title,
  description,
  features,
  buttonText,
  buttonLink,
  isHovered,
  setHovered,
  filled,
}: ServiceCardProps) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6 }}
      whileHover={{ scale: 1.03, y: -10 }}
      onHoverStart={() => setHovered(type)}
      onHoverEnd={() => setHovered(null)}
      className="backdrop-blur-[6px] bg-[rgba(14,36,27,0.7)] border border-[rgba(200,169,91,0.6)] h-[400px] overflow-hidden rounded-[20px] shadow-[0px_0px_40px_0px_rgba(200,169,91,0.08),0px_30px_60px_-5px_rgba(0,0,0,0.4)] p-10 relative"
    >
      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="bg-[#c8a95b] h-[3px] w-[40px] mb-4 origin-left"
      />

      <motion.p
        initial={{ scale: 0 }}
        whileInView={{ scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.4, delay: 0.3 }}
        className="text-[32px] mb-4"
      >
        {icon}
      </motion.p>

      <motion.p
        initial={{ opacity: 0, x: -20 }}
        whileInView={{ opacity: 1, x: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.4 }}
        className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] mb-2"
      >
        {title}
      </motion.p>

      <motion.p
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 0.6, delay: 0.5 }}
        className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[15px] mb-6"
      >
        {description}
      </motion.p>

      <div className="space-y-4 mb-6">
        {features.map((feature, index) => (
          <motion.div
            key={feature}
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: 0.6 + index * 0.1 }}
            className="flex items-center gap-3"
          >
            <div className="bg-[#c8a95b] rounded-[3px] w-[6px] h-[6px]" />
            <p className="font-['Inter:Regular',sans-serif] text-[#a7b3aa] text-[15px]">{feature}</p>
          </motion.div>
        ))}
      </div>

      <Link to={buttonLink}>
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className={`absolute bottom-10 right-10 h-[44px] px-6 rounded-[22px] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[13px] tracking-[0.39px] ${
            filled
              ? "bg-[#c8a95b] text-[#0b1f17]"
              : "bg-transparent border border-[rgba(200,169,91,0.8)] text-[#c8a95b]"
          }`}
        >
          {buttonText}
        </motion.button>
      </Link>
    </motion.div>
  );
}

interface FeaturedWorkProps {
  setVideoModal: (modal: { isOpen: boolean; title: string; category: string }) => void;
}

function FeaturedWork({ setVideoModal }: FeaturedWorkProps) {
  const works = [
    {
      title: "Wedding Highlight",
      category: "Wedding Film",
      year: "2024",
      height: "320px",
      width: "420px",
    },
    {
      title: "Brand Campaign",
      category: "Commercial Ad",
      year: "2024",
      height: "460px",
      width: "340px",
    },
    {
      title: "Couple Story",
      category: "Wedding Film",
      year: "2023",
      height: "220px",
      width: "510px",
    },
    {
      title: "Product Launch",
      category: "Ad Film",
      year: "2024",
      height: "200px",
      width: "420px",
    },
    {
      title: "Cinematic Reel",
      category: "Commercial",
      year: "2024",
      height: "300px",
      width: "510px",
    },
  ];

  return (
    <section className="relative bg-[#0b1f17] py-20 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(180deg, rgb(5, 15, 11) 0%, rgb(11, 31, 23) 50%, rgb(5, 15, 11) 100%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.05)] blur-[60px] left-[520px] rounded-[200px] w-[400px] h-[400px] top-[200px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ FEATURED WORK ✦
        </motion.p>

        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6 mb-16">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[34px] md:text-[48px] lg:text-[56px] leading-[1.1]">
              Stories We've Told
            </p>
            <p className="font-['Inter:Light',sans-serif] font-light text-[#c8a95b] text-[20px] tracking-[1px] mt-2">
              at <span className="font-extrabold">RGL MEDIA</span>
            </p>
          </motion.div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-12 gap-5">
          {works.map((work, index) => (
            <WorkCard key={work.title} work={work} index={index} setVideoModal={setVideoModal} />
          ))}
        </div>
      </div>
    </section>
  );
}

interface WorkCardProps {
  work: {
    title: string;
    category: string;
    year: string;
    height: string;
    width: string;
  };
  index: number;
  setVideoModal: (modal: { isOpen: boolean; title: string; category: string }) => void;
}

function WorkCard({ work, index, setVideoModal }: WorkCardProps) {
  const [isHovered, setIsHovered] = useState(false);

  const gridConfig = [
    { col: "md:col-span-5" },
    { col: "md:col-span-4" },
    { col: "md:col-span-6" },
    { col: "md:col-span-5" },
    { col: "md:col-span-6" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ duration: 0.6, delay: index * 0.1 }}
      whileHover={{ scale: 1.03, y: -10 }}
      onHoverStart={() => setIsHovered(true)}
      onHoverEnd={() => setIsHovered(false)}
      onClick={() => setVideoModal({ isOpen: true, title: work.title, category: work.category })}
      className={`${gridConfig[index].col} bg-[#081711] border border-[rgba(200,169,91,0.5)] overflow-hidden rounded-[16px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.5)] relative cursor-pointer`}
      style={{ height: work.height }}
    >
      <div
        className="absolute inset-0 bg-gradient-to-b from-[#0a1c14] to-[#030a07] rounded-[16px]"
      />
      <div
        className="absolute left-0 right-0 bottom-0 h-[100px] bg-gradient-to-b from-transparent to-[rgba(3,9,6,0.95)]"
      />

      <div className="absolute top-4 left-4 bg-[rgba(11,31,23,0.85)] border border-[rgba(200,169,91,0.4)] h-[28px] px-3 rounded-[14px] flex items-center">
        <p className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[10px] tracking-[0.6px]">
          {work.category}
        </p>
      </div>

      <motion.div
        animate={{ scale: isHovered ? 1.2 : 1, opacity: isHovered ? 1 : 0.8 }}
        transition={{ duration: 0.3 }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[rgba(200,169,91,0.12)] border border-[rgba(200,169,91,0.6)] rounded-[24px] w-[48px] h-[48px] flex items-center justify-center"
      >
        <p className="text-[#c8a95b] text-[18px]">▶</p>
      </motion.div>

      <div className="absolute bottom-4 left-4 right-4">
        <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#f5f5f5] text-[16px] mb-1">
          {work.title}
        </p>
        <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[12px]">
          {work.year}
        </p>
      </div>
    </motion.div>
  );
}

function Testimonials() {
  const testimonials = [
    {
      quote:
        "The wedding film felt like a movie — every moment was captured with so much emotion and beauty. Truly cinematic.",
      name: "Priya & Arjun",
      role: "Wedding Couple, 2024",
    },
    {
      quote:
        "Their ad completely elevated our brand. The quality, storytelling, and execution were world-class. Highly recommend.",
      name: "Nithya Rajan",
      role: "Brand Director, Chennai",
    },
    {
      quote:
        "Watching our product film felt like watching a cinematic trailer. The team truly understood our vision.",
      name: "Karthik M.",
      role: "Founder, StartupCo",
    },
  ];

  return (
    <section className="relative bg-[#132a21] py-20 overflow-hidden">
      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.05)] blur-[40px] left-[620px] rounded-[100px] w-[200px] h-[200px] top-[50px]"
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] text-center tracking-[1.32px] mb-4"
        >
          ✦ CLIENT STORIES ✦
        </motion.p>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[30px] md:text-[40px] lg:text-[48px] text-center mb-12 md:mb-16"
        >
          What Clients Say
        </motion.p>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 50 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              whileHover={{ scale: 1.05, y: -10 }}
              className="backdrop-blur-[5px] bg-[rgba(14,36,27,0.6)] border border-[rgba(200,169,91,0.5)] rounded-[20px] shadow-[0px_20px_40px_-5px_rgba(0,0,0,0.3)] p-7 relative flex flex-col"
            >
              <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#c8a95b] text-[56px] leading-none opacity-70 mb-2">
                "
              </p>

              <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[14px] leading-[24px] mb-6 flex-1">
                {testimonial.quote}
              </p>

              <div className="bg-[#c8a95b] h-[2px] w-[32px] mb-3" />

              <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#f5f5f5] text-[14px] mb-1">
                {testimonial.name}
              </p>
              <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[12px] tracking-[0.36px]">
                {testimonial.role}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}

function AboutSection() {
  const stats = [
    { value: "50+", label: "Films" },
    { value: "5★", label: "Rating" },
    { value: "3+", label: "Years" },
  ];

  return (
    <section className="relative bg-[#0b1f17] py-20 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: "linear-gradient(90deg, rgb(5, 15, 11) 0%, rgb(11, 31, 23) 100%)",
        }}
      />

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative pb-12 pr-6"
          >
            <div className="bg-gradient-to-b border border-[rgba(200,169,91,0.5)] from-[#0a1c14] h-[480px] rounded-[20px] shadow-[0px_30px_60px_-10px_rgba(0,0,0,0.5)] to-[#030a07] relative flex items-center justify-center">
              <div className="absolute top-6 left-6 bg-[rgba(11,31,23,0.85)] border border-[rgba(200,169,91,0.5)] h-[32px] px-4 rounded-[16px] flex items-center">
                <p className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[10px] tracking-[0.8px]">
                  BEHIND THE LENS
                </p>
              </div>

              <div className="text-center">
                <p className="text-[60px] mb-4">🎥</p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px]">
                  Behind the Scenes
                </p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[rgba(200,169,91,0.8)] text-[13px] tracking-[0.78px] mt-2">
                  Chennai · India
                </p>
              </div>

              <motion.div
                initial={{ opacity: 0, scale: 0.8 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.3 }}
                className="absolute bottom-[-30px] right-[-10px] bg-[rgba(11,31,23,0.9)] border border-[rgba(200,169,91,0.5)] h-[80px] rounded-[12px] shadow-[0px_16px_32px_0px_rgba(0,0,0,0.4)] w-[160px] p-4"
              >
                <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#c8a95b] text-[28px]">
                  50+
                </p>
                <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[11px]">
                  Films Delivered
                </p>
              </motion.div>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <p className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] tracking-[1.32px] mb-4">
              ✦ ABOUT US ✦
            </p>

            <div className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[32px] md:text-[44px] lg:text-[52px] leading-[1.15] text-[#f5f5f5] mb-8">
              <p className="mb-0">A Studio Built</p>
              <p>for Storytelling.</p>
            </div>

            <div className="bg-[#c8a95b] h-[2px] w-[50px] mb-6" />

            <div className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[16px] leading-[28px] space-y-4 mb-12">
              <p>
                We are a Chennai-based creative production team focused on cinematic wedding
                storytelling and commercial advertising.
              </p>
              <p>
                Every frame we craft is intentional. Every edit, emotional. We blend technical
                precision with artistic vision to create films that are felt — not just watched.
              </p>
            </div>

            <div className="flex gap-16">
              {stats.map((stat, index) => (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.6, delay: 0.2 + index * 0.1 }}
                >
                  <p className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#c8a95b] text-[32px]">
                    {stat.value}
                  </p>
                  <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[13px] tracking-[0.52px]">
                    {stat.label}
                  </p>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

function CTASection() {
  const particles = [
    { left: "200px", top: "150px", opacity: 0.59 },
    { left: "350px", top: "80px", opacity: 0.52 },
    { left: "1100px", top: "200px", opacity: 0.48 },
    { left: "1200px", top: "100px", opacity: 0.6 },
    { left: "900px", top: "400px", opacity: 0.33 },
    { left: "400px", top: "450px", opacity: 0.34 },
    { left: "700px", top: "80px", opacity: 0.54 },
    { left: "1050px", top: "350px", opacity: 0.41 },
  ];

  return (
    <section className="relative bg-[#0b1f17] py-20 overflow-hidden">
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(ellipse 1440px 600px at 50% 80%, rgba(200,169,91,0.12) 0%, rgba(105,100,57,0.46) 25%, rgba(58,66,40,0.63) 37.5%, rgba(35,48,31,0.715) 43.75%, rgba(11,31,23,0.8) 50%, rgba(5,15,11,1) 100%)",
        }}
      />

      <motion.div
        initial={{ opacity: 0, scale: 0.5 }}
        whileInView={{ opacity: 1, scale: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className="absolute bg-[rgba(200,169,91,0.08)] blur-[60px] left-[520px] rounded-[200px] w-[400px] h-[400px] top-[100px]"
      />

      {particles.map((particle, index) => (
        <motion.div
          key={index}
          initial={{ opacity: 0, scale: 0 }}
          animate={{
            y: [0, -20, 0],
            opacity: [particle.opacity, particle.opacity * 0.5, particle.opacity],
            scale: 1,
          }}
          transition={{
            duration: 3 + index * 0.5,
            repeat: Infinity,
            repeatType: "reverse",
            delay: index * 0.1,
          }}
          className="absolute bg-[rgba(200,169,91,var(--opacity))] rounded-[2px] w-[4px] h-[4px]"
          style={{ left: particle.left, top: particle.top, "--opacity": particle.opacity } as any}
        />
      ))}

      <div className="relative max-w-[1440px] mx-auto px-4 sm:px-8 md:px-20 text-center">
        <motion.div
          initial={{ scaleX: 0 }}
          whileInView={{ scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="bg-[rgba(200,169,91,0.25)] h-px mx-auto w-[320px] mb-6"
        />

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] tracking-[1.32px] mb-6"
        >
          ✦ LET'S COLLABORATE ✦
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[36px] md:text-[56px] lg:text-[72px] leading-[1.15] text-[#f5f5f5] mb-8"
        >
          <p className="mb-0">Let's Create Something</p>
          <p>Timeless.</p>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px] mb-12"
        >
          Your story deserves to be told with cinematic beauty.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.6 }}
          className="flex gap-4 justify-center"
        >
          <motion.a
            href="https://wa.me/919842612090"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05, boxShadow: "0px 12px 40px 0px rgba(200,169,91,0.6)" }}
            whileTap={{ scale: 0.95 }}
            className="bg-[#c8a95b] h-[56px] px-8 rounded-[28px] shadow-[0px_8px_32px_0px_rgba(200,169,91,0.5)] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#0b1f17] text-[14px] tracking-[0.42px] flex items-center"
          >
            💬 WhatsApp
          </motion.a>

          <motion.a
            href="https://instagram.com/rglmedia"
            target="_blank"
            rel="noopener noreferrer"
            whileHover={{ scale: 1.05, borderColor: "rgba(200,169,91,1)" }}
            whileTap={{ scale: 0.95 }}
            className="bg-transparent border border-[rgba(200,169,91,0.7)] h-[56px] px-8 rounded-[28px] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#c8a95b] text-[14px] tracking-[0.42px] flex items-center transition-colors"
          >
            📸 Instagram
          </motion.a>

          <motion.a
            href="tel:+919842612090"
            whileHover={{ scale: 1.05, borderColor: "rgba(200,169,91,1)" }}
            whileTap={{ scale: 0.95 }}
            className="bg-transparent border border-[rgba(200,169,91,0.7)] h-[56px] px-8 rounded-[28px] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[#c8a95b] text-[14px] tracking-[0.42px] flex items-center transition-colors"
          >
            📞 Call Now
          </motion.a>
        </motion.div>
      </div>
    </section>
  );
}
