// EXAMPLE: How to add a background video to your Hero Section
// This shows how to replace the gradient background with a video

import { motion } from "motion/react";
import BackgroundVideo from "../components/BackgroundVideo";

export function HeroWithBackgroundVideo() {
  return (
    <BackgroundVideo
      // Option 1: Use a direct video file (recommended for background videos)
      videoUrl="/videos/hero-background.mp4"
      type="direct"
      // Option 2: Use YouTube (not recommended for backgrounds due to controls)
      // videoUrl="https://www.youtube.com/watch?v=YOUR_VIDEO_ID"
      // type="youtube"
      overlay={true}
      overlayOpacity={0.7} // Adjust darkness (0.0 to 1.0)
      overlayColor="#0b1f17" // Your brand color
      className="h-[900px]"
    >
      <section className="relative h-full overflow-hidden">
        <div className="relative max-w-[1440px] mx-auto px-20 h-full flex items-center">
          <div className="flex-1">
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[11px] tracking-[1.32px] mb-6"
            >
              ✦ CINEMATIC PRODUCTION ✦
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.8, delay: 0.5 }}
              className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[83px] leading-[96px] mb-8"
            >
              <p className="mb-0">
                <span className="text-[#f5f5f5]">At </span>
                <span className="text-[#e5b94c]">RGL MEDIA</span>
              </p>
              <p>
                <span className="text-[#f5f5f5]">Creativity meets </span>
                <span className="text-[#e5b94c]">Strategy.</span>
              </p>
            </motion.div>

            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.9 }}
              className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[18px] leading-[30px] max-w-[440px] mb-8"
            >
              We Create Stories That Define Modern Media
            </motion.p>

            {/* Your existing buttons and content */}
          </div>
        </div>
      </section>
    </BackgroundVideo>
  );
}

/*
 * SETUP STEPS FOR BACKGROUND VIDEO:
 *
 * 1. Create a /public/videos/ folder in your project
 * 2. Add your video file (e.g., hero-background.mp4)
 * 3. Optimize the video:
 *    - Keep it short (5-15 seconds that loops seamlessly)
 *    - Compress to under 5MB for fast loading
 *    - Recommended size: 1920x1080 or 1280x720
 *    - Use H.264 codec for best browser support
 *
 * 4. Replace your current HeroSection with this component
 *
 * OPTIMIZATION TIPS:
 * - Use tools like HandBrake to compress videos
 * - Remove audio from background videos (saves space)
 * - Test on slower connections to ensure smooth playback
 * - Consider using a poster image as fallback
 */

// ALTERNATIVE: Multiple background video options
export function HeroWithVideoOptions() {
  const videoOptions = {
    // Option 1: Cinematic wedding footage
    wedding: {
      url: "/videos/wedding-bg.mp4",
      overlay: 0.65,
    },
    // Option 2: Commercial/corporate feel
    commercial: {
      url: "/videos/commercial-bg.mp4",
      overlay: 0.7,
    },
    // Option 3: Creative/artistic
    creative: {
      url: "/videos/creative-bg.mp4",
      overlay: 0.6,
    },
  };

  // Choose which video to use
  const currentVideo = videoOptions.wedding;

  return (
    <BackgroundVideo
      videoUrl={currentVideo.url}
      type="direct"
      overlay={true}
      overlayOpacity={currentVideo.overlay}
      overlayColor="#0b1f17"
      className="h-[900px]"
    >
      {/* Your hero content */}
    </BackgroundVideo>
  );
}

// ALTERNATIVE: Hero with subtle particle video effect
export function HeroWithParticleVideo() {
  return (
    <section className="relative h-[900px] overflow-hidden">
      {/* Background gradient (fallback) */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "linear-gradient(32.0054deg, rgb(11, 31, 23) 28.571%, rgb(19, 42, 33) 71.429%, rgb(5, 15, 11) 100%)",
        }}
      />

      {/* Subtle video overlay */}
      <div className="absolute inset-0 opacity-30">
        <video
          src="/videos/particles.mp4"
          autoPlay
          loop
          muted
          playsInline
          className="w-full h-full object-cover mix-blend-screen"
        />
      </div>

      {/* Content layer */}
      <div className="relative z-10">{/* Your hero content */}</div>
    </section>
  );
}
