import { motion, AnimatePresence } from "motion/react";
import { useEffect } from "react";
import VideoPlayer from "./VideoPlayer";

interface VideoModalProps {
  isOpen: boolean;
  onClose: () => void;
  videoTitle: string;
  videoCategory: string;
  videoUrl?: string;
  videoType?: "youtube" | "vimeo" | "direct";
}

export default function VideoModal({
  isOpen,
  onClose,
  videoTitle,
  videoCategory,
  videoUrl,
  videoType = "youtube"
}: VideoModalProps) {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };

    if (isOpen) {
      document.addEventListener("keydown", handleEscape);
      document.body.style.overflow = "hidden";
    }

    return () => {
      document.removeEventListener("keydown", handleEscape);
      document.body.style.overflow = "unset";
    };
  }, [isOpen, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={onClose}
            className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50"
          />

          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: 20 }}
            transition={{ duration: 0.3, ease: "easeOut" }}
            className="fixed inset-0 z-50 flex items-center justify-center p-8"
            onClick={onClose}
          >
            <div
              onClick={(e) => e.stopPropagation()}
              className="relative w-full max-w-[1200px] bg-[#0b1f17] border border-[rgba(200,169,91,0.6)] rounded-[24px] overflow-hidden shadow-[0px_40px_80px_-10px_rgba(0,0,0,0.8)]"
            >
              <button
                onClick={onClose}
                className="absolute top-4 right-4 z-10 w-[40px] h-[40px] bg-[rgba(11,31,23,0.9)] border border-[rgba(200,169,91,0.5)] rounded-full flex items-center justify-center text-[#c8a95b] hover:bg-[rgba(200,169,91,0.2)] transition-colors"
              >
                ✕
              </button>

              <div className="p-6">
                <div className="mb-4">
                  <span className="inline-block bg-[rgba(11,31,23,0.9)] border border-[rgba(200,169,91,0.4)] px-3 py-1 rounded-full font-['Inter:Medium',sans-serif] font-medium text-[#c8a95b] text-[10px] tracking-[0.6px]">
                    {videoCategory}
                  </span>
                  <h3 className="font-['Inter:Extra_Bold',sans-serif] font-extrabold text-[#f5f5f5] text-[32px] mt-3">
                    {videoTitle}
                  </h3>
                </div>

                {videoUrl ? (
                  <VideoPlayer
                    videoUrl={videoUrl}
                    type={videoType}
                    controls={true}
                  />
                ) : (
                  <div className="aspect-video bg-gradient-to-b from-[#0a1c14] to-[#030a07] rounded-[16px] flex items-center justify-center">
                    <div className="text-center">
                      <div className="bg-[rgba(200,169,91,0.15)] border-2 border-[rgba(200,169,91,0.8)] rounded-full w-[80px] h-[80px] flex items-center justify-center mx-auto mb-4">
                        <div className="w-0 h-0 border-t-[14px] border-t-transparent border-l-[24px] border-l-[#c8a95b] border-b-[14px] border-b-transparent ml-1" />
                      </div>
                      <p className="font-['Inter:Light',sans-serif] font-light text-[#a7b3aa] text-[16px]">
                        Video player placeholder
                      </p>
                      <p className="font-['Inter:Light',sans-serif] font-light text-[rgba(200,169,91,0.7)] text-[13px] mt-2">
                        In production, embed your Vimeo or YouTube video here
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
